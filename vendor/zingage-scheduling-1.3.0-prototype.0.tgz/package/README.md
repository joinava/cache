# @zingage/scheduling

Helpers that decide when work runs in Node.js. The package has two parts:

- [Time slicing](#time-slicing): collection helpers that yield to the event loop, so long synchronous work does not block it.
- [Task collapsing and batching](#task-collapsing-and-batching): classes that decide which callers share work, how work is sent in batches, and when an owner can close.

## Time slicing

Cooperative collection helpers for synchronous work and generator callbacks in Node.js. Each helper defaults to a new independent budget with a 4 ms processing allowance.

```ts
import {
  TimeSliceBudget,
  timeSlicedForEach,
  timeSlicedMap,
} from "@zingage/scheduling";

// Independent calls do not consume each other's budget.
await Promise.all([
  timeSlicedMap(firstItems, transform),
  timeSlicedMap(secondItems, transform),
]);

// Connected calls share the remaining allowance explicitly.
const budget = new TimeSliceBudget();
await Promise.all([
  timeSlicedMap(firstItems, transform, budget),
  timeSlicedForEach(secondItems, processItem, budget),
]);
```

### Budget semantics

The package measures elapsed time around synchronous callbacks and result accumulation. It subtracts that measured time from the budget. Waiting at a yield and unrelated work between measured steps do not consume the budget.

If A uses 1 ms and finishes, connected B gets the remaining 3 ms. If A exhausts the budget, A replenishes it before yielding. B can then use the new 4 ms while A waits. A does not replenish the budget when it resumes. Unrelated C uses a separate budget and cannot consume A/B's allowance.

One callback or iterator step cannot be interrupted. Nested helpers started inside a synchronous callback cannot interrupt that containing callback. Their work counts once toward a shared budget. Garbage collection and operating-system pauses inside a measured step count as elapsed processing time. This is not CPU-time accounting or a hard event-loop delay bound. Work outside the helpers does not count. `timeSlicedMap` and `timeSlicedForEach` also accept generator callbacks.

### Synchronous callbacks

Ordinary callbacks, predicates, key functions, and `measure` work must be synchronous. The types accept any result, including generic results such as `(item) => item`. TypeScript cannot reject a promise result without also rejecting generic results. So the rule is checked at runtime: if a non-generator callback returns a promise or other thenable (an object or function with a `then` method), the helper throws a `TypeError` before it uses the value. An `async` callback compiles, and throws on its first call. For async work, use a generator callback with `yield* waitFor(...)`.

The constructor is `new TimeSliceBudget(sliceMs = DEFAULT_TIME_SLICE_MS, now = performance.now, yieldToEventLoop = setImmediate)`. `sliceMs` must be positive and finite. `now` must be a monotonic clock in milliseconds. The budget binds the clock to `performance` because Node's default clock requires that receiver. The default yield function is Node's promise-based `setImmediate`. A custom yield function must let the event loop advance; `Promise.resolve()` does not provide that behavior. Optionally pass a budget directly as each helper's last argument to share its allowance.

### Helpers

| Helper                     | Result                                                                       |
| -------------------------- | ---------------------------------------------------------------------------- |
| `timeSlicedForEach`        | Runs callbacks in input order; returns `Promise<void>`.                      |
| `timeSlicedMap`            | Returns transformed values in input order.                                   |
| `timeSlicedFlatMap`        | Flattens each callback's list incrementally, including large lists.          |
| `timeSlicedFilter`         | Returns matching items in input order.                                       |
| `timeSlicedSome`           | Returns `true` at the first match; stops there.                              |
| `timeSlicedFind`           | Returns the first match, or `undefined`; stops there.                        |
| `timeSlicedGroupBy`        | Returns a `Map` with first-seen key order and input order within each group. |
| `timeSlicedSort`           | Returns a new stable sorted array with a synchronous comparator.             |
| `timeSlicedMapFromEntries` | Builds a `Map`; the last value wins for repeated keys.                       |

All helpers accept synchronous iterables. Callbacks receive the item and its zero-based index. Callback, iterator, and yield errors reject the operation. Callback failures still consume their measured processing time. The loops use native `for…of` cleanup rules. Callback and yield failures close the active iterator when it provides `return()`, while failures from `next()` do not. An existing callback or yield error takes precedence if cleanup also throws. Iterator advancement does not consume the budget.

The package does not infer parent operations or use global budgets. It does not serialize mutations or impose ordering between concurrent calls. Backend consumers use this package. The former `time-sliced-map.ts` utility has been removed.

### Generator callbacks

`timeSlicedMap` and `timeSlicedForEach` finish each generator callback before starting the next item. Use `yield* waitFor(promise)` to suspend with an inferred result type:

```ts
import { timeSlicedMap, waitFor } from "@zingage/scheduling";

const results = await timeSlicedMap(
  items,
  function* (item) {
    const data = yield* waitFor(load(item));
    return process(data);
  },
  budget,
);
```

The budget measures every `next()` and `throw()` call, including synchronous work after suspension. Promise waits do not consume the budget. A rejected promise enters the generator through `throw()`, so generator `catch` and `finally` blocks run normally. Recovery can yield another promise. An unhandled error rejects the traversal and prevents later callbacks from starting. If the scheduler fails, the helper closes the callback generator and awaits its yielded cleanup. Cleanup does not call the failed scheduler again. The original scheduler error takes precedence over cleanup errors.

Generator callbacks may also yield promises directly, but their resumed values have type `unknown`. Use `waitFor` for typed values. A synchronous segment cannot be interrupted. Break expensive callbacks into smaller generator segments. Nested helpers share accounting, but cannot interrupt the synchronous segment that starts them.

### Sorting

`timeSlicedSort(items, compare, budget?)` returns a new array and preserves the
input order of values that compare equal. It uses a stable merge sort and checks
the budget after each merge write, including tail copies. Input copying and
result extraction also use the budget. Comparators must be synchronous; one
comparator call cannot be interrupted. The comparator receives all values,
including `undefined`. A `NaN` comparison result acts like zero.

```ts
const budget = new TimeSliceBudget();
const sorted = await timeSlicedSort(
  [3, 1, 2],
  (left, right) => left - right,
  budget,
);
```

For async sort keys, use generator callbacks with `timeSlicedMap` to load the
keys, then pass a synchronous comparator to `timeSlicedSort`.

## Task collapsing and batching

These parts decide when work runs, which callers share it, and when an owner
can close. None of them knows what the work is. Their owners supply that
knowledge through callbacks. `@zingage/cache` uses them for its Store reads
and producer calls.

| Export                                              | What it does                                                               |
| --------------------------------------------------- | -------------------------------------------------------------------------- |
| [`CollapsedTaskCreator`](#collapsedtaskcreator)     | Lets requests with the same key share one pending task, with cancellation. |
| [`wrapWithTaskCollapsing`](#wrapwithtaskcollapsing) | Wraps a task-starting function so that equal calls share a pending task.   |
| [`Batcher`](#batcher)                               | Collects items and sends them to one `dispatch` function in batches.       |
| [`PendingPromisesTracker`](#pendingpromisestracker) | Tracks promises until they settle, so that `close` can wait for them.      |

The pieces compose like this:

- A caller that sends each task at once uses a `CollapsedTaskCreator` alone.
  It has nothing to batch.
- A caller that sends tasks in bulk uses a `CollapsedTaskCreator` in front of
  a `Batcher`. The creator decides which requests start new tasks. The
  batcher groups the new tasks into calls.
- A caller that never shares work, such as a cache that reads from its store,
  uses a `Batcher` alone.

`Batcher` and `wrapWithTaskCollapsing` accept a `Logger`. By default, they
write to the [`debug`](https://www.npmjs.com/package/debug) namespaces
`@zingage/scheduling:batcher` and `@zingage/scheduling:collapsed-task-creator`.
A callback that breaks a contract of this package, for example a `dispatch`
that returns the wrong number of results, causes a `SchedulingContractError`.

### CollapsedTaskCreator

A `CollapsedTaskCreator` takes a batch of task requests in one
`startOrRideTasks` call. Each task request is an input plus an optional
`AbortSignal`. For each one, the creator either starts a new task or rides a
pending task with the same key.

- `makeKey` derives each input's key. A key of `undefined` means the input
  never shares work.
- A task request rides a pending task only if the task started no more than
  `collapseTasksMs` ago, has not settled, and is not cancelled.
- The tasks that one call starts go to the owner's `schedule` callback in one
  call. So a bulk caller's new inputs become one unit of work.
- Each task has its own signal. It aborts only when every request on the task
  is cancelled. A request without a signal can never be cancelled, so it keeps
  the task alive.
- The creator counts the requests that ride each task, for diagnostics.
- `drain` waits until every task has settled, including tasks started while it
  waits.

The creator does not queue, batch, or limit work. The `schedule` callback owns
that.

### wrapWithTaskCollapsing

`wrapWithTaskCollapsing` wraps a function that starts a task and returns a
promise. A later call with the same arguments gets the pending task's promise
instead of a new task, but only while the task still runs and only within
`collapseTasksMs` of its start. It is a mix of memoizing, throttling, and
promise sharing. It runs on `CollapsedTaskCreator`, with one task request per
call.

It does not support cancellation, so an individual caller cannot cancel a
task that other callers share. Use `CollapsedTaskCreator` when you need
cancellation.

```ts
import { wrapWithTaskCollapsing } from "@zingage/scheduling";

const fetchUser = wrapWithTaskCollapsing(
  async (id: string) => api.getUser(id),
  1_000,
  ([id]) => id,
);
```

### PendingPromisesTracker

An owner tracks each piece of accepted work, then drains the tracker in its
`close`.

- `track(promise)` tracks a promise until it settles. Tracking never creates
  an unhandled rejection.
- `run(start)` tracks before it calls `start`, and turns a synchronous throw
  into a rejection.
- `drain()` waits until no tracked promise is pending, including promises
  tracked while it waits.

The tracker has no closed state. Each owner decides what happens to work that
arrives after its `close` starts, and in what order it drains its trackers.

### Batcher

`Batcher` collects units of work and sends them to one `dispatch` function in
batches. It replaces [DataLoader](https://github.com/graphql/dataloader) in
`@zingage/cache`.

#### Same as DataLoader

When no signal aborts and nobody calls `flush`, `close` or `dispatchNow`, a
`Batcher` behaves like a DataLoader built with `cache: false`:

- `enqueue` corresponds to `load`, or to `loadMany` for several items.
- A batch opens with its first entry and schedules its own dispatch.
- The default schedule is DataLoader's. The batch dispatches in a
  `process.nextTick` that a resolved promise queues. So the batch takes every
  entry from the current event-loop turn and from the promise jobs that the
  turn queues.
- `batchScheduleFn` replaces the default schedule, as in DataLoader. It
  receives the batch's dispatch callback.
- A batch takes entries until it holds `maxBatchSize` of them. The next entry
  opens a new batch, with its own scheduled dispatch. A full batch does not
  dispatch early.
- `dispatch` returns a promise of one result per item, in order. An `Error`
  in a result slot rejects only that item. A rejection, or a synchronous
  throw, rejects every item in the batch with the same error.
- A repeated input is sent again. The batcher never shares work between
  items. `CollapsedTaskCreator` does that.

[`batcher.dataloader.test.ts`](./src/batcher.dataloader.test.ts) holds
DataLoader's own tests, ported to the batcher. The file header lists the
tests that it leaves out, and why.

#### Added to DataLoader

- **Cancellation.** An item can carry an `AbortSignal`. When the signal
  aborts while the item waits in a batch, the item leaves the batch and its
  result rejects with the signal's reason. The item also frees its slot, so
  that a later entry can join the batch. An item whose signal already
  aborted is rejected at once and never queued. Work that has dispatched
  always completes.
- **`dispatchNow`.** It sends new items at once, without a batch. It can also
  pull queued entries forward: the caller passes the handles that `enqueue`
  returned, including handles from other callers. One `dispatchNow` call is
  one `dispatch` call, which `maxBatchSize` never splits.
- **`flush`.** It dispatches every pending batch now. It also drops
  `batchScheduleFn`, so later batches use the default schedule. An owner
  calls it when its shutdown starts, because its own schedule may stop
  firing then.
- **`close`.** It flushes, then resolves once no batch is pending and no
  dispatch is running. It waits for work that a dispatch enqueues into the
  same batcher. After `close`, `enqueue` and `dispatchNow` log a warning, but
  the work still runs.
- **Dispatch facts.** `dispatch` receives each item's queue wait in
  milliseconds, and an `autoBatched` flag that says whether a batch or
  `dispatchNow` sent the call.
- **`preserveAsyncContext`.** When it is on, each batch dispatches in the
  async context of the `enqueue` call that opened the batch. Use it when
  `batchScheduleFn` runs its callbacks from an unrelated context, or when
  `flush` must not run a batch in the closer's context.

#### Not in the Batcher

- **No cache.** The batcher has no `clear`, `clearAll`, `prime`,
  `cacheKeyFn` or `cacheMap`. Its owner and `CollapsedTaskCreator` own
  caching and work sharing.
- **No `name` and no `batch: false`.** Use `maxBatchSize: 1` to send each item
  alone.

#### Known differences from DataLoader

These differences remain on purpose. No test covers them.

| Behavior                                                                               | DataLoader                                                         | Batcher                                                                         |
| -------------------------------------------------------------------------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------------- |
| Default `maxBatchSize`                                                                 | No limit                                                           | 20 (`DEFAULT_MAX_BATCH_SIZE`)                                                   |
| A `maxBatchSize` that is not an integer, such as `1.5`                                 | Accepted                                                           | Throws a `TypeError`                                                            |
| `dispatch` throws or rejects with a value that is not an `Error`                       | Rejects each load with that value                                  | Rejects each item with an `Error` whose `cause` is that value                   |
| `dispatch` throws synchronously, or resolves with a value of the wrong shape or length | Rejects each load with DataLoader's own `TypeError` message        | Rejects each item with the original error, or with a `SchedulingContractError`  |
| When results settle                                                                    | One microtask after the `dispatch` promise resolves                | About two microtasks later, because `Promise.try` adopts the `dispatch` promise |
| `batchScheduleFn` runs its callback synchronously                                      | Strands the entry in a dispatched batch, so its load never settles | Schedules a call's batches only after all of the call's entries are in place    |

## Dispatcher and Sharing (prototype)

This is a prototype of one model for queueing, batching, limiting, expediting
and sharing work. `Batcher` and `CollapsedTaskCreator` are unchanged, and do
not use it.

The parts:

- An `Item` is one unit of work. It is `waiting`, then `running`, then
  `settled`. Every other part reads that state from the item. A caller that
  holds an item can call `item.expedite()` to skip the wait that accumulates
  a batch, and `item.cancel(reason)` while the item waits.
- A waiting set holds the items that wait. It owns their order, which items
  can share a call, and when an item is ready. `fifoBatches` is a DataLoader
  queue. Without a waiting set, each item is its own call, ready at once.
  `groupedBatches` lets only items of one group share a call.
- An admission decides when a call may start. `new ConcurrencyLimit(n)` allows
  `n` calls at one time. An admission holds only requests for a slot. The
  work stays in the waiting set, where it can still be joined, expedited or
  cancelled, and a call takes the items that are ready when it starts.
- `createDispatcher` connects a waiting set, an optional admission, and the
  `invoke` function that runs one call.
- `Sharing` sits in front of a dispatcher. Requests with the same key share
  one item. Its `canJoin` function decides whether a request joins an item
  that already exists, from the item's state and times.

```ts
import {
  ConcurrencyLimit,
  createDispatcher,
  fifoBatches,
  Sharing,
} from "@zingage/scheduling";

type Request = { id: string; joinInFlight?: false };

const dispatcher = createDispatcher({
  waiting: fifoBatches({ maxBatchSize: 20 }),
  admission: new ConcurrencyLimit(4),
  invoke: async (items: readonly Item<string, User>[]) =>
    fetchUsers(items.map((item) => item.input)),
});

const sharing = new Sharing<Request, string, User>({
  keyOf: (request) => request.id,
  canJoin: (item, request, now) => {
    if (item.state === "waiting") return true;
    if (request.joinInFlight === false) return "inFlight";
    return now - (item.startedAt ?? now) <= 3_000 ? true : "tooOld";
  },
  start: (requests) => dispatcher.submitMany(requests.map(({ id }) => id)),
});

// Join or start the work, and wait in the automatic batch.
const user = await sharing.request({ id: "u1" }, signal).result;

// The same for a known set, without the accumulation wait.
const outcomes = sharing.requestMany(ids.map((id) => ({ request: { id } })));
outcomes.forEach(({ item }) => item?.expedite());
```

Notes on behavior:

- The dispatcher starts calls once for each burst of microtasks. So items
  that become ready in one turn form calls together.
- With an admission, the dispatcher asks for one slot for each call that the
  ready items form, and withdraws the requests that it no longer needs. If
  the admission refuses a request, the items of one call are cancelled with
  an `AdmissionRefusedError`.
- `submit` and `submitMany` take two options. `expedite: true` makes the
  work ready at once, without the wait that accumulates a batch, and arms
  no schedule for it. `signal` cancels the work that still waits when the
  signal aborts. Work whose call has started always completes. Use `signal`
  for work that one caller owns, not for work that a `Sharing` starts.
- With no waiting set, `submit` starts the item's call itself when it can:
  always without an admission, and with one when the admission gives the
  slot at once.
- A call that waited for a slot runs in the async context in which it
  became ready, not in the context of the work that freed the slot.
- `Sharing.requestMany` shares one item between equal requests of one call,
  whatever `canJoin` says. It computes every key and decision before it
  starts anything.
