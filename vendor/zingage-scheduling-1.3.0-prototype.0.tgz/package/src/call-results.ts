import { SchedulingContractError } from "./scheduling-contract-error.js";

/** Throws unless a call returned exactly one result for each item. */
export function assertResultCount(
  results: readonly unknown[],
  itemCount: number,
): void {
  if (!Array.isArray(results) || results.length !== itemCount) {
    throw new SchedulingContractError(
      "invoke must return one result or Error for each item",
    );
  }
}

/** Returns `error` if it is an Error, and wraps any other value in one. */
export function asError(error: unknown): Error {
  return error instanceof Error
    ? error
    : new Error("Scheduled work failed", { cause: error });
}
