import { AdmissionRefusedError, type Admission } from "./admission.js";
import { Item, type ItemOwner } from "./item.js";
import { runCall, RunningCalls, type Invoke } from "./run-call.js";
import { SlotRequests } from "./slot-requests.js";
import { cancelWaitingOnAbort, type SubmitOptions } from "./submit-options.js";
import {
  oneByOne,
  type MakeWaitingSet,
  type WaitingSet,
} from "./waiting-set.js";

/**
 * Accepts work, and runs it in calls. A {@link WaitingSet} decides which
 * items wait, which are ready, and which share a call. An optional
 * {@link Admission} decides when a call may start. The dispatcher only
 * connects them: it forms a call at the time the call starts, from the items
 * that are ready then.
 *
 * It does not share work. For that, put a `Sharing` in front of it.
 */
export type Dispatcher<Input, Result> = {
  /** Accepts one unit of work. */
  submit(input: Input, options?: SubmitOptions): Item<Input, Result>;
  /**
   * Accepts several units of work in one step: either all of them enter the
   * waiting set together, or the call throws and none does. The options
   * apply to all of them.
   */
  submitMany(
    inputs: readonly Input[],
    options?: SubmitOptions,
  ): Item<Input, Result>[];
  /** Makes all waiting work ready now. */
  flush(): void;
  /** Flushes, then resolves when no work waits or runs. */
  close(): Promise<void>;
};

const defaultNow = () => performance.now();

/**
 * The dispatcher for work that never waits: each item is its own call, and
 * starts inside `submit`. It has no queue and no pump.
 */
class AtOnceDispatcher<Input, Result>
  implements Dispatcher<Input, Result>, ItemOwner<Input, Result>
{
  readonly #invoke: Invoke<Input, Result>;
  readonly #calls = new RunningCalls();
  readonly now: () => number;

  constructor(invoke: Invoke<Input, Result>, now: () => number) {
    this.#invoke = invoke;
    this.now = now;
  }

  // An item never waits here. It is cancelled only by a signal that has
  // aborted before the item's call could start.
  expedited(): void {}
  cancelled(): void {}

  submit(input: Input, options?: SubmitOptions): Item<Input, Result> {
    const item = new Item<Input, Result>(
      input,
      this,
      undefined,
      options?.expedite === true,
    );
    const signal = options?.signal;
    if (signal?.aborted) {
      item.cancel(signal.reason);
      return item;
    }
    this.#calls.started();
    // oxlint-disable-next-line no-void -- RunningCalls counts the call for close; callers await the item's result.
    void runCall([item], this.#invoke, item.submittedAt, this.#calls.finished);
    return item;
  }

  submitMany(
    inputs: readonly Input[],
    options?: SubmitOptions,
  ): Item<Input, Result>[] {
    return inputs.map((input) => this.submit(input, options));
  }

  flush(): void {}

  async close(): Promise<void> {
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Loops until idle, because a call can submit more work.
    while (this.#calls.count > 0) {
      await this.#calls.nextChange();
    }
  }
}

/** The general dispatcher. See {@link Dispatcher}. */
class QueueingDispatcher<Input, Result, Context>
  implements Dispatcher<Input, Result>, ItemOwner<Input, Result>
{
  readonly #waiting: WaitingSet<Input, Result, Context>;
  /** The requests for slots at the admission. Undefined when there is no admission. */
  readonly #slots: SlotRequests<Context> | undefined;
  readonly #invoke: Invoke<Input, Result>;
  readonly now: () => number;

  /** True while a pump is queued, so that one burst of changes pumps once. */
  #pumpQueued = false;
  /** The number of items that wait, so `close` knows when none is left. */
  #waitingCount = 0;
  /**
   * True while this dispatcher cancels items that the waiting set does not
   * hold: the items of a refused call, which the set gave away, or items
   * whose signal had aborted before they were added. The set must not be
   * told to remove them, and the code that cancels them keeps the count.
   */
  #cancellingUnheldItems = false;
  readonly #calls = new RunningCalls();
  #closing: Promise<void> | undefined;

  /**
   * @param options.pumpAtOnce Whether to start the ready calls inside
   *   `submit`, and not at the end of the current microtasks. That is right
   *   when each item is its own call: then nothing can join a call later in
   *   the turn.
   */
  constructor(options: {
    waiting: MakeWaitingSet<Input, Result, Context>;
    pumpAtOnce: boolean;
    admission: Admission<Context> | undefined;
    invoke: Invoke<Input, Result>;
    now: () => number;
  }) {
    this.#slots =
      options.admission === undefined
        ? undefined
        : new SlotRequests(
            options.admission,
            this.#startCall,
            this.#refuseCall,
          );
    this.#invoke = options.invoke;
    this.now = options.now;
    this.#waiting = options.waiting(
      options.pumpAtOnce ? this.#pump : this.#queuePump,
    );
  }

  expedited(item: Item<Input, Result>): void {
    this.#waiting.expedite(item);
  }

  cancelled(item: Item<Input, Result>): void {
    if (this.#cancellingUnheldItems) return;
    this.#waitingCount -= 1;
    this.#waiting.remove(item);
    // Fewer ready calls can need fewer requests for a slot.
    if (this.#slots?.hasWaiting) this.#queuePump();
    this.#calls.noteChange();
  }

  submit(input: Input, options?: SubmitOptions): Item<Input, Result> {
    const expedite = options?.expedite === true;
    const item = new Item<Input, Result>(input, this, undefined, expedite);
    this.#accept([item], expedite, options?.signal);
    return item;
  }

  submitMany(
    inputs: readonly Input[],
    options?: SubmitOptions,
  ): Item<Input, Result>[] {
    const now = this.now();
    const expedite = options?.expedite === true;
    const items = inputs.map((input) => new Item(input, this, now, expedite));
    this.#accept(items, expedite, options?.signal);
    return items;
  }

  /** Adds new items to the waiting set, and connects them to the signal. */
  #accept(
    items: readonly Item<Input, Result>[],
    ready: boolean,
    signal: AbortSignal | undefined,
  ): void {
    if (signal?.aborted) {
      // The items never wait, so the waiting set never sees them.
      this.#cancelUnheld(items, signal.reason);
      return;
    }

    // Counted first: the waiting set can make the items ready inside `add`,
    // and their calls can then start there, which counts them out.
    this.#waitingCount += items.length;
    try {
      this.#waiting.add(items, ready);
    } catch (error) {
      this.#waitingCount -= items.length;
      throw error;
    }
    if (signal !== undefined) cancelWaitingOnAbort(items, signal);
  }

  /** Cancels items that the waiting set does not hold. The caller keeps the count. */
  #cancelUnheld(items: readonly Item<Input, Result>[], reason: unknown): void {
    this.#cancellingUnheldItems = true;
    try {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Cancels each item for its side effect.
      items.forEach((item) => {
        item.cancel(reason);
      });
    } finally {
      this.#cancellingUnheldItems = false;
    }
  }

  flush(): void {
    this.#waiting.flush();
  }

  // oxlint-disable-next-line typescript/promise-function-async -- Repeated calls must return the same promise.
  close(): Promise<void> {
    this.#closing ??= (async () => {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Loops until idle, because a call can submit more work.
      while (this.#waitingCount > 0 || this.#calls.count > 0) {
        const changed = this.#calls.nextChange();
        this.#waiting.flush();
        await changed;
      }
    })();
    return this.#closing;
  }

  /**
   * Queues one pump for the end of the current microtasks. So several items
   * that become ready in one turn, for example by `expedite`, form calls
   * together. A function, not a method, so that the waiting set can hold it.
   */
  readonly #queuePump = (): void => {
    if (this.#pumpQueued) return;
    this.#pumpQueued = true;
    queueMicrotask(this.#pump);
  };

  /**
   * Starts the ready calls. With an admission, it asks for one slot for each
   * ready call instead, and withdraws the requests that no ready call needs
   * any more. So the admission's own queue holds one request for each call
   * that waits, and can limit or reject them.
   */
  readonly #pump = (): void => {
    this.#pumpQueued = false;
    const ready = this.#waiting.readyCalls();
    if (this.#slots !== undefined) {
      this.#slots.match(ready);
      return;
    }

    // oxlint-disable-next-line zingage/no-restricted-syntax -- Starts each ready call; the path of every call.
    for (const [context, calls] of ready) {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Starts each ready call; the path of every call.
      for (let started = 0; started < calls; started += 1) {
        // oxlint-disable-next-line no-void -- RunningCalls counts the call for close.
        void this.#startCall(context);
      }
    }
  };

  /**
   * Cancels the items of one call that the admission refused. A function,
   * not a method, so that `SlotRequests` can hold it.
   */
  readonly #refuseCall = (context: Context, cause: unknown): void => {
    const error = new AdmissionRefusedError(
      "The call was refused admission",
      cause === undefined ? undefined : { cause },
    );
    const items = this.#waiting.take(context);
    this.#waitingCount -= items.length;
    this.#cancelUnheld(items, error);
    this.#calls.noteChange();
  };

  /**
   * Takes one call's items for `context`, and runs the call. A function,
   * not a method, so that `SlotRequests` can hold it.
   *
   * @returns The call's promise, or undefined when no item was left to run.
   */
  // oxlint-disable-next-line typescript/promise-function-async -- Returns the call's promise, or undefined, synchronously.
  readonly #startCall = (context: Context): Promise<void> | undefined => {
    const items = this.#waiting.take(context);
    if (items.length === 0) return undefined;
    this.#waitingCount -= items.length;

    // Counted before `invoke` runs: an `invoke` that calls `close`
    // synchronously must find this call.
    this.#calls.started();
    return runCall(items, this.#invoke, this.now(), this.#calls.finished);
  };
}

/** The options of {@link createDispatcher} that do not depend on the waiting set. */
type CommonDispatcherOptions<Input, Result> = {
  /** Runs one call. */
  invoke: Invoke<Input, Result>;
  /** The clock for item times. Defaults to `performance.now()`. */
  now?: (() => number) | undefined;
};

/**
 * Makes a {@link Dispatcher}.
 *
 * @param options.waiting Makes the waiting set, which decides how items
 *   accumulate into calls: for example `fifoBatches()`. Without it, each
 *   item is its own call, and is ready at once.
 * @param options.admission Decides when a call may start. Without it, a
 *   ready call starts at once. Its context is `undefined`, unless the
 *   waiting set gives each call a context, as `groupedBatches` does.
 *
 * Without `waiting`, `submit` starts the item's call itself when it can:
 * always without an admission, and with one when the admission gives the
 * slot at once.
 */
export function createDispatcher<Input, Result>(
  options: CommonDispatcherOptions<Input, Result> & {
    waiting?: MakeWaitingSet<Input, Result, undefined> | undefined;
    admission?: Admission<undefined> | undefined;
  },
): Dispatcher<Input, Result>;
export function createDispatcher<Input, Result, Context>(
  options: CommonDispatcherOptions<Input, Result> & {
    waiting: MakeWaitingSet<Input, Result, Context>;
    admission?: Admission<Context> | undefined;
  },
): Dispatcher<Input, Result>;
export function createDispatcher<Input, Result, Context>(
  options: CommonDispatcherOptions<Input, Result> & {
    waiting?: MakeWaitingSet<Input, Result, Context> | undefined;
    admission?: Admission<Context> | undefined;
  },
): Dispatcher<Input, Result> {
  const now = options.now ?? defaultNow;
  // Work that is its own call, ready at once, and needs no admission never
  // waits. So it needs no queue.
  if (options.waiting === undefined && options.admission === undefined) {
    return new AtOnceDispatcher(options.invoke, now);
  }
  return new QueueingDispatcher({
    // With no waiting set, nothing gathers items into a call, so a call
    // needs no wait for the rest of the turn.
    pumpAtOnce: options.waiting === undefined,
    waiting:
      options.waiting ??
      // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- The overloads allow no waiting set only when Context is undefined, which is the context of oneByOne.
      (oneByOne as MakeWaitingSet<Input, Result, Context>),
    admission: options.admission,
    invoke: options.invoke,
    now,
  });
}
