/**
 * Reports that a caller broke a contract of this package. Examples are a
 * `dispatch` or `schedule` callback that returns the wrong number of results,
 * and a `schedule` callback that requests a key it is starting a task for.
 */
export class SchedulingContractError extends Error {
  override readonly name: string = "SchedulingContractError";
}
