import {
  CollapsedTaskCreator,
  type TaskStartReason,
} from "./collapsed-task-creator.js";
import { defaultLoggersByComponent, type Logger } from "./logger.js";

// The creator reserves `undefined` for inputs that never share work, but here
// `undefined` is an ordinary key. So it stands in for `undefined` with a
// key that no caller can produce.
const undefinedKey = Symbol("undefined key");

/**
 * The "started" log line for each reason a call starts a task. A call here
 * has no signal, so its task is never cancelled, and its key is never
 * `undefined` for the creator. But every reason has a line, so the log stays
 * accurate if that changes.
 */
const startedMessages: Record<TaskStartReason, string> = {
  noPendingTask:
    "started new task b/c there was no in-progress task for these args",
  pendingTaskTooOld:
    "started new task; there _was_ an in-progress one, but it's too old",
  pendingTaskCancelled:
    "started new task; there _was_ an in-progress one, but it was cancelled",
  noKey: "started new task b/c these args have no key",
};

/**
 * Wraps a function that starts a task and returns a promise for its result.
 * The returned function behaves like the original, except that a call reuses
 * the promise of an earlier call if and only if: 1) the calls have the same
 * key, which `makeKey` derives from their arguments [a la memoize]; 2) less
 * than `collapseTasksMs` milliseconds have passed since the earlier call
 * started its task [a la throttle]; and 3) that task is still running
 * [unique]. Otherwise, the call calls through to the original function. So it
 * is sort of a combination of memoize, throttle, and promise chaining.
 *
 * It runs on {@link CollapsedTaskCreator}: each call is one task request,
 * whose input carries the call's arguments and key. See that class for why
 * these semantics are useful.
 *
 * It does not support task cancellation. A call takes no `AbortSignal`, so no
 * individual caller can cancel a task that other callers share. Users who
 * need cancellation should use `CollapsedTaskCreator` directly.
 *
 * @param taskCreator The task creation function
 * @param collapseTasksMs The number of milliseconds up until which, if a caller
 *   tries to start the same task while a previous version of the task is still
 *   running, the promise for the result of the currently-running task will be
 *   returned instead.
 * @param makeKey A function for converting the arguments passed to the task
 *   creation into a cache key, like in your standard memoize implementation.
 * @param logger Receives the trace lines that each call writes.
 */
export function wrapWithTaskCollapsing<Args extends unknown[], Key, Result>(
  taskCreator: (...args: Args) => Promise<Result>,
  collapseTasksMs: number,
  makeKey: (args: Args) => Key,
  logger: Logger = defaultLoggersByComponent["collapsed-task-creator"],
) {
  const logTrace = logger.bind(null, "collapsed-task-creator", "trace");

  // The creator's input carries the key, so `makeKey` runs once per call and
  // every log line below can include the key.
  const creator = new CollapsedTaskCreator({
    collapseTasksMs,
    makeKey: ({ taskKey }: { args: Args; taskKey: Key }) =>
      taskKey === undefined ? undefinedKey : taskKey,
    schedule: (toStart) =>
      toStart.map(({ input: { args, taskKey }, startReason }) => {
        logTrace(startedMessages[startReason], args);
        const taskRes = taskCreator(...args);
        logTrace("pending = new state for taskKey/args", { args, taskKey });
        return {
          result: taskRes.finally(() => {
            logTrace("completed = new state for taskKey/args", {
              args,
              taskKey,
            });
          }),
          handle: undefined,
        };
      }),
  });

  return async (...args: Args) => {
    const taskKey = makeKey(args);
    logTrace("requested = new state for taskKey/args", { args, taskKey });

    const [{ result, rode }] = creator.startOrRideTasks([
      { input: { args, taskKey } },
    ]);

    if (rode) {
      logTrace(
        "reusing result from prior, still-in-progress run of task for args/taskKey",
        { args, taskKey },
      );
    }

    return result;
  };
}
