import { SchedulingContractError } from "./scheduling-contract-error.js";

/**
 * What an {@link Item} tells the dispatcher that made it. The item gets its
 * owner in its constructor, so an item always has one.
 */
export type ItemOwner<Input, Result> = {
  /** The item was expedited while it waited. */
  expedited(item: Item<Input, Result>): void;
  /** The item was cancelled while it waited. Its result is already rejected. */
  cancelled(item: Item<Input, Result>): void;
  /** The clock for the item's times. Every item of one owner uses the same clock. */
  now(): number;
};

/** How a started item settles. */
export type ItemOutcome<Result> =
  | { readonly ok: true; readonly value: Result }
  | { readonly ok: false; readonly error: unknown };

/**
 * One unit of work, from the time a dispatcher accepts it until it settles.
 * It is the handle that every part of the scheduling shares: the waiting set
 * holds it, `invoke` receives it, and a sharing layer indexes it.
 *
 * An item is `"waiting"`, then `"running"`, then `"settled"`. It can also go
 * from `"waiting"` straight to `"settled"`, when it is cancelled. While it
 * waits, it is first not `ready`, and then `ready` for a call. Only the
 * methods of this class change the state, so the state, `ready`,
 * `startedAt` and `result` always agree.
 */
export class Item<Input, Result> {
  readonly input: Input;
  /** The owner's clock time at which the item was made. */
  readonly submittedAt: number;
  /**
   * The item's result. A rejection is always marked as handled, so an item
   * that nobody awaits is safe.
   */
  readonly result: Promise<Result>;

  readonly #owner: ItemOwner<Input, Result>;
  readonly #settlement: PromiseWithResolvers<Result>;
  #state: "waiting" | "running" | "settled" = "waiting";
  #startedAt: number | undefined;
  #ready = false;
  #expedited = false;
  /**
   * Called once, synchronously, when the item settles. One listener is kept
   * without a list, because most items have at most one.
   */
  #settleListeners: (() => void) | readonly (() => void)[] | undefined;

  /**
   * @param submittedAt The owner's clock time now. An owner that makes many
   *   items at one time passes one reading, so that it reads the clock once.
   */
  constructor(
    input: Input,
    owner: ItemOwner<Input, Result>,
    submittedAt: number = owner.now(),
  ) {
    this.input = input;
    this.#owner = owner;
    this.submittedAt = submittedAt;
    this.#settlement = Promise.withResolvers<Result>();
    this.result = this.#settlement.promise;
  }

  /**
   * Rejects `result`, and marks the rejection as handled. It does that only
   * here, when the item fails, so an item that succeeds costs no extra
   * promise.
   */
  #reject(error: unknown): void {
    this.#settlement.reject(error);
    // oxlint-disable-next-line no-void -- Marks the rejection as handled; callers still get the rejected promise.
    void this.result.catch(() => {});
  }

  get state(): "waiting" | "running" | "settled" {
    return this.#state;
  }

  /** The owner's clock time at which the item's call started. Undefined while it waits. */
  get startedAt(): number | undefined {
    return this.#startedAt;
  }

  /**
   * True once the item is ready for a call: its waiting set no longer holds
   * it back to accumulate a batch. It stays true after the item starts.
   */
  get ready(): boolean {
    return this.#ready;
  }

  /** True once `expedite` was called while the item waited. */
  get expedited(): boolean {
    return this.#expedited;
  }

  /**
   * Asks for the item's call to start as soon as it can, without the wait
   * that accumulates a batch. It does nothing unless the item waits.
   */
  expedite(): void {
    if (this.#state !== "waiting" || this.#expedited) return;
    this.#expedited = true;
    this.#owner.expedited(this);
  }

  /**
   * Marks an item that waits as ready for a call. Only the waiting set that
   * holds the item calls it, when it stops holding the item back.
   *
   * @returns Whether the item became ready now. False if it was already
   *   ready, or does not wait.
   */
  markReady(): boolean {
    if (this.#state !== "waiting" || this.#ready) return false;
    this.#ready = true;
    return true;
  }

  /**
   * Cancels an item that waits: rejects its result with `reason`, and takes
   * it out of the waiting work. It does nothing once the item runs, because
   * work that started always completes.
   */
  cancel(reason: unknown): void {
    if (this.#state !== "waiting") return;
    this.#state = "settled";
    this.#reject(reason);
    this.#notifySettled();
    this.#owner.cancelled(this);
  }

  /**
   * Calls `listener` once, synchronously, when the item settles. It costs
   * less than a reaction on `result`, and it runs before any such reaction.
   * A listener on an item that has already settled never runs. A listener
   * must not throw.
   */
  onSettled(listener: () => void): void {
    if (this.#state === "settled") return;
    const current = this.#settleListeners;
    this.#settleListeners =
      current === undefined
        ? listener
        : typeof current === "function"
          ? [current, listener]
          : [...current, listener];
  }

  #notifySettled(): void {
    const listeners = this.#settleListeners;
    if (listeners === undefined) return;
    this.#settleListeners = undefined;
    if (typeof listeners === "function") {
      listeners();
      return;
    }
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Calls each listener for its side effect.
    listeners.forEach((listener) => {
      listener();
    });
  }

  /**
   * Moves the item from `"waiting"` to `"running"`, and sets `startedAt`.
   * Only the dispatcher that owns the item calls it, when it takes the item
   * for a call.
   *
   * @param startedAt The owner's clock time now. An owner that starts many
   *   items at one time passes one reading.
   * @returns The function that settles the item. It acts once. Only the
   *   caller of `start` has it, so nothing else can settle a running item.
   * @throws {SchedulingContractError} If the item does not wait.
   */
  start(
    startedAt: number = this.#owner.now(),
  ): (outcome: ItemOutcome<Result>) => void {
    if (this.#state !== "waiting") {
      throw new SchedulingContractError(
        `An item can start only while it waits, but it is ${this.#state}`,
      );
    }
    this.#state = "running";
    this.#ready = true;
    this.#startedAt = startedAt;

    return (outcome) => {
      if (this.#state !== "running") return;
      this.#state = "settled";
      if (outcome.ok) this.#settlement.resolve(outcome.value);
      else this.#reject(outcome.error);
      this.#notifySettled();
    };
  }
}
