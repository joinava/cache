import { AsyncLocalStorage } from "node:async_hooks";
import { DEFAULT_MAX_BATCH_SIZE, type BatchOptions } from "./batcher.js";
import type { Item } from "./item.js";

/**
 * Holds the items that wait for a call. It owns their order, which items can
 * share a call, and when an item is ready for one. So it also owns any key
 * that groups items: the dispatcher never sees one.
 *
 * Each ready item belongs to one context. The dispatcher asks for admission
 * with that context, and takes one call's items for it.
 */
export type WaitingSet<Input, Result, Context> = {
  /**
   * Adds every item, or throws and adds none.
   *
   * @param ready Whether the items are ready at once, as if each of them
   *   was expedited. Then they do not accumulate, and the set arms no
   *   schedule or timer for them.
   */
  add(items: readonly Item<Input, Result>[], ready: boolean): void;
  /**
   * Takes out an item that was cancelled. The dispatcher calls it once, for
   * an item that the set holds, after the item's state changed.
   */
  remove(item: Item<Input, Result>): void;
  /** Makes an item ready now. */
  expedite(item: Item<Input, Result>): void;
  /** Makes every item ready now, for a shutdown. */
  flush(): void;
  /**
   * For each context that has ready items: the number of calls that those
   * items form now. The array is a snapshot, which the set does not change
   * later.
   */
  readyCalls(): readonly (readonly [context: Context, calls: number])[];
  /**
   * Takes out and returns the items of one call for `context`. It chooses
   * them now, so a call that waited for admission gets the items that are
   * ready when it starts. Empty when no item of the context is ready.
   */
  take(context: Context): Item<Input, Result>[];
};

/**
 * Makes a {@link WaitingSet} for one dispatcher. The set calls `onReady`
 * each time `readyCalls()` can have grown. It gets `onReady` here, so a set
 * always has it, and no two dispatchers share one set.
 *
 * The makers in this file return functions that are generic in the types
 * that they do not use. So `createDispatcher` infers those types from its
 * `invoke`, and a caller does not write them.
 */
export type MakeWaitingSet<Input, Result, Context> = (
  onReady: () => void,
) => WaitingSet<Input, Result, Context>;

/** A {@link Lane} queue is rebuilt only when it holds at least this many dead places. */
const MIN_DEAD_TO_REBUILD = 32;

/**
 * Items in arrival order, in two stages: items that still accumulate, and
 * items that are ready.
 *
 * Both stages are arrays, because adding to an array and reading it in order
 * cost much less than the same on a `Set`. An item that leaves a stage out
 * of order (it was cancelled, or expedited) stays in the array, and is
 * skipped later: the item itself says whether it still waits, and whether it
 * is ready. The two counts are exact at all times.
 */
class Lane<Input, Result> {
  /** Items that accumulate. It can also hold items that were cancelled or made ready since. */
  #accumulating: Item<Input, Result>[] = [];
  /** The live items in `#accumulating`: those that wait and are not ready. */
  #accumulatingCount = 0;
  /** Ready items, from `#readyHead` on. It can also hold items that were cancelled since. */
  #ready: Item<Input, Result>[] = [];
  #readyHead = 0;
  /** The live items in `#ready`: those that still wait. */
  #readyCount = 0;

  get accumulatingCount(): number {
    return this.#accumulatingCount;
  }

  get isEmpty(): boolean {
    return this.#accumulatingCount === 0 && this.#readyCount === 0;
  }

  add(item: Item<Input, Result>): void {
    // oxlint-disable-next-line zingage/no-restricted-syntax -- The lane owns this queue.
    this.#accumulating.push(item);
    this.#accumulatingCount += 1;
  }

  /** Adds an item that is ready at once. */
  addReady(item: Item<Input, Result>): void {
    item.markReady();
    // oxlint-disable-next-line zingage/no-restricted-syntax -- The lane owns this queue.
    this.#ready.push(item);
    this.#readyCount += 1;
  }

  /**
   * Counts out an item of this lane that was cancelled. Its place in the
   * queue is skipped later. When a queue holds more such places than live
   * items, the queue is rebuilt, so that it does not keep cancelled items
   * for as long as one live item waits.
   */
  remove(item: Item<Input, Result>): void {
    if (item.ready) {
      this.#readyCount -= 1;
      const dead = this.#ready.length - this.#readyHead - this.#readyCount;
      if (dead >= MIN_DEAD_TO_REBUILD && dead > this.#readyCount) {
        this.#ready = this.#ready
          .slice(this.#readyHead)
          .filter((it) => it.state === "waiting");
        this.#readyHead = 0;
      }
      return;
    }

    this.#accumulatingCount -= 1;
    const dead = this.#accumulating.length - this.#accumulatingCount;
    if (dead >= MIN_DEAD_TO_REBUILD && dead > this.#accumulatingCount) {
      this.#accumulating = this.#accumulating.filter(
        (it) => it.state === "waiting" && !it.ready,
      );
    }
  }

  /** Makes one item of this lane ready. Returns whether it was accumulating. */
  makeReady(item: Item<Input, Result>): boolean {
    if (!item.markReady()) return false;
    this.#accumulatingCount -= 1;
    // oxlint-disable-next-line zingage/no-restricted-syntax -- The lane owns this queue.
    this.#ready.push(item);
    this.#readyCount += 1;
    return true;
  }

  /** Makes every item ready. Returns whether any item was accumulating. */
  makeAllReady(): boolean {
    const moved = this.#accumulatingCount;
    // `markReady` refuses an item that was cancelled, or made ready since.
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Moves each live item in order; a hot path.
    for (const item of this.#accumulating) {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- The lane owns this queue.
      if (item.markReady()) this.#ready.push(item);
    }
    this.#accumulating.length = 0;
    this.#accumulatingCount = 0;
    this.#readyCount += moved;
    return moved > 0;
  }

  /** The number of calls that the ready items form, at `maxBatchSize` items a call. */
  readyCalls(maxBatchSize: number): number {
    if (this.#readyCount === 0) return 0;
    return maxBatchSize === Infinity
      ? 1
      : Math.ceil(this.#readyCount / maxBatchSize);
  }

  /** Takes out the first ready items, at most `maxBatchSize`. */
  take(maxBatchSize: number): Item<Input, Result>[] {
    const ready = this.#ready;
    const items: Item<Input, Result>[] = [];
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Reads the queue in order, and skips cancelled items; a hot path.
    while (items.length < maxBatchSize && this.#readyHead < ready.length) {
      // oxlint-disable-next-line typescript/no-non-null-assertion -- The loop condition keeps the index in range.
      const item = ready[this.#readyHead]!;
      this.#readyHead += 1;
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Collects the taken items in order.
      if (item.state === "waiting") items.push(item);
    }
    this.#readyCount -= items.length;

    if (this.#readyHead === ready.length) {
      ready.length = 0;
      this.#readyHead = 0;
    } else if (this.#readyHead >= 1024 && this.#readyHead * 2 >= ready.length) {
      // A queue that never empties, for example behind an admission, must
      // not keep every item that it ever held.
      this.#ready = ready.slice(this.#readyHead);
      this.#readyHead = 0;
    }
    return items;
  }
}

function assertMaxBatchSize(maxBatchSize: number): void {
  if (
    maxBatchSize !== Infinity &&
    (!Number.isInteger(maxBatchSize) || maxBatchSize < 1)
  ) {
    throw new TypeError("maxBatchSize must be a positive integer");
  }
}

/**
 * Items wait in arrival order, in one context (`undefined`), and a call
 * takes the first `maxBatchSize` ready ones.
 *
 * Items accumulate as a DataLoader's do. The first item that accumulates
 * arms `batchScheduleFn`. When its callback runs, every item that
 * accumulated until then becomes ready. The default schedule is the next
 * tick after the current microtasks, so items from one event-loop turn
 * become ready together. `expedite` makes one item ready without that wait.
 *
 * `preserveAsyncContext` runs that callback in the async context of the
 * `add` that armed it. `flush` then runs the same callback, so calls that
 * `flush`, or a dispatcher's `close`, sends early also start in that
 * context, and not in the context of the caller of `flush`.
 *
 * `flush` drops `batchScheduleFn`, which the owner can stop during a
 * shutdown. Later items use the default schedule.
 */
export function fifoBatches(
  options: BatchOptions = {},
): <Input, Result>(
  onReady: () => void,
) => WaitingSet<Input, Result, undefined> {
  const maxBatchSize = options.maxBatchSize ?? DEFAULT_MAX_BATCH_SIZE;
  assertMaxBatchSize(maxBatchSize);

  return <Input, Result>(
    onReady: () => void,
  ): WaitingSet<Input, Result, undefined> => {
    const lane = new Lane<Input, Result>();
    const state: {
      batchScheduleFn: BatchOptions["batchScheduleFn"];
      /**
       * Defined while the schedule is armed: the callback that the schedule
       * got. Every path that makes the accumulated items ready runs it, so
       * all of them run in the same async context.
       */
      armedCallback: (() => void) | undefined;
    } = { batchScheduleFn: options.batchScheduleFn, armedCallback: undefined };

    const makeAllReady = () => {
      state.armedCallback = undefined;
      if (lane.makeAllReady()) onReady();
    };
    const arm = () => {
      if (state.armedCallback !== undefined) return;
      const callback = options.preserveAsyncContext
        ? AsyncLocalStorage.bind(makeAllReady)
        : makeAllReady;
      state.armedCallback = callback;
      if (state.batchScheduleFn) state.batchScheduleFn(callback);
      // oxlint-disable-next-line no-void -- Schedules the callback; nothing awaits it.
      else void Promise.resolve().then(() => process.nextTick(callback));
    };

    return {
      add(items, ready) {
        if (items.length === 0) return;
        if (ready) {
          // oxlint-disable-next-line zingage/no-restricted-syntax -- Adds each item for its side effect.
          items.forEach((item) => {
            lane.addReady(item);
          });
          onReady();
          return;
        }
        // oxlint-disable-next-line zingage/no-restricted-syntax -- Adds each item for its side effect.
        items.forEach((item) => {
          lane.add(item);
        });
        // After the items are in place: a schedule can run its callback
        // synchronously.
        arm();
      },
      remove(item) {
        lane.remove(item);
      },
      expedite(item) {
        if (lane.makeReady(item)) onReady();
      },
      flush() {
        state.batchScheduleFn = undefined;
        // While nothing is armed, nothing accumulates, so there is nothing
        // to make ready.
        state.armedCallback?.();
      },
      readyCalls() {
        const calls = lane.readyCalls(maxBatchSize);
        return calls === 0 ? [] : [[undefined, calls]];
      },
      take: () => lane.take(maxBatchSize),
    };
  };
}

/**
 * The waiting set of a dispatcher that was given none: every item is ready
 * at once, and is its own call. Nothing accumulates, so `expedite` and
 * `flush` do nothing. An item waits here only for an admission's slot. A
 * dispatcher with no admission does not use a waiting set at all.
 */
export function oneByOne<Input, Result>(
  onReady: () => void,
): WaitingSet<Input, Result, undefined> {
  const lane = new Lane<Input, Result>();
  return {
    add(items) {
      if (items.length === 0) return;
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Adds each item for its side effect.
      items.forEach((item) => {
        lane.addReady(item);
      });
      onReady();
    },
    remove(item) {
      lane.remove(item);
    },
    expedite() {},
    flush() {},
    readyCalls() {
      // Each ready item is its own call.
      const calls = lane.readyCalls(1);
      return calls === 0 ? [] : [[undefined, calls]];
    },
    take: () => lane.take(1),
  };
}

/**
 * Items wait in groups. Only items of one group can share a call, and each
 * group is its own context. `groupOf` gives an item's group, which is
 * compared as a `Map` key. It runs once for each item, in `add`.
 *
 * A group's items accumulate until `maxWaitMs` after the first of them
 * arrived, or until `maxBatchSize` of them accumulate. Then all of them
 * become ready. `maxBatchSize` is also the most items that one call takes.
 * It defaults to no limit.
 */
export function groupedBatches<Input, Group>(options: {
  groupOf: (input: Input) => Group;
  maxWaitMs: number;
  maxBatchSize?: number;
}): <Result>(onReady: () => void) => WaitingSet<Input, Result, Group> {
  const { groupOf, maxWaitMs } = options;
  const maxBatchSize = options.maxBatchSize ?? Infinity;
  assertMaxBatchSize(maxBatchSize);

  return <Result>(onReady: () => void): WaitingSet<Input, Result, Group> => {
    type GroupState = {
      readonly group: Group;
      readonly lane: Lane<Input, Result>;
      /** Defined while items of the group accumulate. */
      timer: ReturnType<typeof setTimeout> | undefined;
    };
    const groups = new Map<Group, GroupState>();
    const groupByItem = new WeakMap<Item<Input, Result>, GroupState>();

    const makeGroupReady = (state: GroupState) => {
      clearTimeout(state.timer);
      state.timer = undefined;
      if (state.lane.makeAllReady()) onReady();
    };
    const dropIfEmpty = (state: GroupState) => {
      if (!state.lane.isEmpty) return;
      clearTimeout(state.timer);
      state.timer = undefined;
      groups.delete(state.group);
    };

    return {
      add(items, ready) {
        // Every group is computed before any item joins one, so a `groupOf`
        // that throws adds nothing.
        const itemGroups = items.map((item) => groupOf(item.input));
        // oxlint-disable-next-line zingage/no-restricted-syntax -- Adds each item to its group for its side effect.
        items.forEach((item, index) => {
          // oxlint-disable-next-line typescript/no-non-null-assertion -- One group was computed for each item. A runtime check would be wrong, because Group can include undefined.
          const group = itemGroups[index]!;
          const state: GroupState = groups.get(group) ?? {
            group,
            lane: new Lane(),
            timer: undefined,
          };
          groups.set(group, state);
          groupByItem.set(item, state);
          if (ready) {
            state.lane.addReady(item);
            return;
          }
          state.lane.add(item);
          if (state.lane.accumulatingCount >= maxBatchSize) {
            makeGroupReady(state);
          } else {
            state.timer ??= setTimeout(() => {
              makeGroupReady(state);
            }, maxWaitMs);
          }
        });
        if (ready && items.length > 0) onReady();
      },
      remove(item) {
        const state = groupByItem.get(item);
        if (state === undefined) return;
        state.lane.remove(item);
        dropIfEmpty(state);
      },
      expedite(item) {
        if (groupByItem.get(item)?.lane.makeReady(item)) onReady();
      },
      flush() {
        // oxlint-disable-next-line zingage/no-restricted-syntax -- Makes each group ready for its side effect.
        groups.forEach(makeGroupReady);
      },
      readyCalls: () =>
        groups
          .values()
          .map(
            (state) =>
              [state.group, state.lane.readyCalls(maxBatchSize)] as const,
          )
          .filter(([, calls]) => calls > 0)
          .toArray(),
      take(context) {
        const state = groups.get(context);
        if (state === undefined) return [];
        const items = state.lane.take(maxBatchSize);
        dropIfEmpty(state);
        return items;
      },
    };
  };
}
