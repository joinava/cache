import type { Admission } from "./admission.js";

type Start = () => PromiseLike<unknown> | undefined;

/**
 * One request that waits for a slot. It is also the listener of its own
 * signal, so a request that waits costs one object, and no function.
 */
class Waiter {
  readonly start: Start;
  readonly #waiters: Set<Waiter>;
  readonly #signal: AbortSignal;
  readonly #answer: (admitted: boolean) => void;

  /**
   * @param waiters The queue that holds this request while it waits. The
   *   request takes itself out when its signal aborts.
   * @param answer Resolves the promise that `admit` returned.
   */
  constructor(
    start: Start,
    waiters: Set<Waiter>,
    signal: AbortSignal,
    answer: (admitted: boolean) => void,
  ) {
    this.start = start;
    this.#waiters = waiters;
    this.#signal = signal;
    this.#answer = answer;
  }

  /** Withdraws the request. The signal calls it on abort. */
  handleEvent(): void {
    this.#waiters.delete(this);
    this.#answer(false);
  }

  /** Tells the request that its `start` was called. */
  started(): void {
    this.#signal.removeEventListener("abort", this);
    this.#answer(true);
  }
}

/**
 * An {@link Admission} with a fixed number of slots. A request that finds no
 * free slot waits, and gets a slot in first-in, first-out order. It never
 * refuses a request. It ignores the context, so one limit covers every
 * context. Several dispatchers can share one limit.
 *
 * `start` should not throw. If it does, it uses no slot, and the requests
 * that wait still get their slots. Then the error is thrown: from `admit`
 * when `start` ran in that call, and otherwise from the callback that freed
 * the slot, where it becomes an unhandled rejection.
 */
export class ConcurrencyLimit implements Admission<unknown> {
  readonly #maxConcurrent: number;
  /**
   * The number of slots in use. A slot is in use while its `start` runs, and
   * then until the promise that `start` returned settles.
   */
  #runningCount = 0;
  /**
   * The requests that wait for a slot. A `Set` keeps insertion order, and
   * removes any member in constant time, so a withdrawal does not search
   * the queue.
   */
  readonly #waiters = new Set<Waiter>();
  /**
   * True while `#grantSlots` runs. A slot that frees during that time, for
   * example because a start returned `undefined`, goes to the loop that
   * already runs. So a long row of such starts uses a loop, not recursion.
   */
  #grantingSlots = false;
  /** The errors that starts threw, until they are thrown. Undefined while there is none. */
  #startErrors: unknown[] | undefined;

  /**
   * @param maxConcurrent The number of slots. It must be a positive integer.
   *   Otherwise the constructor throws a `TypeError`.
   */
  constructor(maxConcurrent: number) {
    if (!Number.isInteger(maxConcurrent) || maxConcurrent < 1) {
      throw new TypeError("maxConcurrent must be a positive integer");
    }
    this.#maxConcurrent = maxConcurrent;
  }

  /** The number of slots in use. */
  get runningCount(): number {
    return this.#runningCount;
  }

  /** The number of requests that wait for a slot. */
  get waitingCount(): number {
    return this.#waiters.size;
  }

  // oxlint-disable-next-line typescript/promise-function-async -- Answers synchronously when it can, so a free slot costs no promise.
  admit(
    _context: unknown,
    signal: AbortSignal,
    start: Start,
  ): boolean | Promise<boolean> {
    if (signal.aborted) return false;
    if (this.#runningCount < this.#maxConcurrent && this.#waiters.size === 0) {
      this.#run(start);
      this.#afterSlotChange();
      return true;
    }

    const { promise, resolve } = Promise.withResolvers<boolean>();
    const waiter = new Waiter(start, this.#waiters, signal, resolve);
    this.#waiters.add(waiter);
    signal.addEventListener("abort", waiter, { once: true });
    return promise;
  }

  /**
   * Frees one slot when its work settles. It reads nothing from the work, so
   * every slot uses this one function. An arrow function, so that it keeps
   * `this` as a promise callback.
   */
  readonly #free = (): void => {
    this.#runningCount -= 1;
    this.#afterSlotChange();
  };

  /**
   * Calls `start` in a free slot. The slot counts as in use before `start`
   * runs, so an `admit` call that `start` makes cannot use the same slot.
   * The slot frees at once when `start` returns `undefined` or throws.
   */
  #run(start: Start): void {
    this.#runningCount += 1;
    const work = this.#callStart(start);
    if (work === undefined) {
      this.#runningCount -= 1;
      return;
    }
    // oxlint-disable-next-line no-void -- Frees the slot on settle; the caller owns the promise.
    void work.then(this.#free, this.#free);
  }

  /** Calls `start`. Keeps the error if it throws, so that the caller can go on. */
  #callStart(start: Start): PromiseLike<unknown> | undefined {
    try {
      return start();
    } catch (error) {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Collects the errors of the starts, in order.
      (this.#startErrors ??= []).push(error);
      return undefined;
    }
  }

  /**
   * Runs after a slot can have freed: gives the free slots to the requests
   * that wait, and then throws the errors that starts threw. It throws only
   * after every slot is given away, so that one bad start does not strand
   * the other requests.
   */
  #afterSlotChange(): void {
    if (this.#waiters.size > 0) this.#grantSlots();

    const errors = this.#startErrors;
    if (errors === undefined) return;
    this.#startErrors = undefined;
    if (errors.length === 1) throw errors[0];
    throw new AggregateError(errors, "More than one start threw");
  }

  /** Gives free slots to the requests that wait, in order. */
  #grantSlots(): void {
    if (this.#grantingSlots) return;
    this.#grantingSlots = true;
    try {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Loops until no slot is free or nothing waits; each start can change both.
      while (this.#runningCount < this.#maxConcurrent) {
        const [waiter] = this.#waiters;
        if (waiter === undefined) break;
        this.#waiters.delete(waiter);
        this.#run(waiter.start);
        waiter.started();
      }
    } finally {
      this.#grantingSlots = false;
    }
  }
}
