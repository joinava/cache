import { asError, assertResultCount } from "./call-results.js";
import type { Item } from "./item.js";

/**
 * Runs one call. It resolves with one result or Error for each item, in
 * order. A rejection fails every item of the call.
 */
export type Invoke<Input, Result> = (
  items: readonly Item<Input, Result>[],
) => Promise<readonly (Result | Error)[]>;

/** A promise that is already resolved, for a call that settled inside `runCall`. */
const SETTLED = Promise.resolve();

/**
 * Starts `items`, runs one call for them, and settles each of them from its
 * result. It calls `onDone` once, when every item has settled. The returned
 * promise resolves then, and never rejects.
 *
 * It adds one promise to the one that `invoke` returns, and no more: this is
 * the path of every call.
 *
 * @param startedAt The owner's clock time now, for every item of the call.
 */
// oxlint-disable-next-line typescript/promise-function-async -- Returns the call's own chain; an async wrapper would add promises.
export function runCall<Input, Result>(
  items: readonly Item<Input, Result>[],
  invoke: Invoke<Input, Result>,
  startedAt: number,
  onDone: () => void,
): Promise<void> {
  const settles = items.map((item) => item.start(startedAt));
  const fail = (error: unknown) => {
    // A settle function acts once, so an item that already has its result
    // keeps it.
    const failure = asError(error);
    try {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Settles each item for its side effect.
      settles.forEach((settle) => {
        settle({ ok: false, error: failure });
      });
    } finally {
      onDone();
    }
  };
  const succeed = (results: readonly (Result | Error)[]) => {
    try {
      assertResultCount(results, items.length);
    } catch (error) {
      fail(error);
      return;
    }
    try {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Settles each item for its side effect.
      settles.forEach((settle, index) => {
        // oxlint-disable-next-line typescript/no-non-null-assertion -- assertResultCount checked the length. A runtime check would be wrong, because Result can include undefined.
        const result = results[index]!;
        settle(
          result instanceof Error
            ? { ok: false, error: result }
            : { ok: true, value: result },
        );
      });
    } finally {
      onDone();
    }
  };

  try {
    return invoke(items).then(succeed, fail);
  } catch (error) {
    // `invoke` threw, or broke its type and returned no promise.
    fail(error);
    return SETTLED;
  }
}

/**
 * Counts the calls that run, and lets `close` wait until none does. It keeps
 * no promise for a call: a count costs nothing on the path of every call.
 */
export class RunningCalls {
  #count = 0;
  /** Defined while something waits for a change. */
  #changed: PromiseWithResolvers<void> | undefined;

  get count(): number {
    return this.#count;
  }

  started(): void {
    this.#count += 1;
  }

  /** A function, not a method, so that it can be passed as a callback. */
  readonly finished = (): void => {
    this.#count -= 1;
    this.noteChange();
  };

  /** Wakes whoever waits in `nextChange`. */
  noteChange(): void {
    const changed = this.#changed;
    if (changed === undefined) return;
    this.#changed = undefined;
    changed.resolve();
  }

  /** Resolves at the next `noteChange` or `finished`. */
  // oxlint-disable-next-line typescript/promise-function-async -- Returns the shared promise of the next change.
  nextChange(): Promise<void> {
    this.#changed ??= Promise.withResolvers<void>();
    return this.#changed.promise;
  }
}
