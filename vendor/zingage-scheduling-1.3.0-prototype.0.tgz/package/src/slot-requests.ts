import { AsyncLocalStorage } from "node:async_hooks";
import type { Admission } from "./admission.js";

/** Runs a function in an async context that was captured earlier. */
type RunInContext = ReturnType<typeof AsyncLocalStorage.snapshot>;

/** One request to the admission, for the slot of one call. */
type SlotRequest<Context> = {
  readonly context: Context;
  /** Withdraws the request while it waits. */
  readonly controller: AbortController;
  /** True once the request was admitted, refused or withdrawn. */
  answered: boolean;
  /**
   * Defined exactly while the request waits for the admission's answer. The
   * admission then calls `start` later, from the callback of other work that
   * frees a slot. This function runs the call in the async context in which
   * the call became ready, as a call that needs no admission runs.
   */
  runInContext: RunInContext | undefined;
};

/**
 * The reason of every withdrawal. `abort()` with no reason makes an error
 * with a stack trace each time, which costs much more than the rest of a
 * withdrawal.
 */
const WITHDRAWN = new Error("The request for a slot is no longer needed");

/**
 * Keeps one request for a slot at the admission for each call that is
 * ready. It holds only the requests that the admission has not answered
 * yet. A request that the admission answers at once, in the `admit` call,
 * is never stored, and costs no async context: that is the path of every
 * call while a slot is free.
 */
export class SlotRequests<Context> {
  readonly #admission: Admission<Context>;
  readonly #startCall: (context: Context) => Promise<void> | undefined;
  readonly #refuseCall: (context: Context, cause: unknown) => void;
  /** For each context: the requests that wait for an answer, oldest first. */
  readonly #waiting = new Map<Context, Set<SlotRequest<Context>>>();

  /**
   * @param startCall Starts one call for a context. Returns the call's
   *   promise, or undefined when nothing was left to run.
   * @param refuseCall Cancels one call's items for a context.
   */
  constructor(
    admission: Admission<Context>,
    startCall: (context: Context) => Promise<void> | undefined,
    refuseCall: (context: Context, cause: unknown) => void,
  ) {
    this.#admission = admission;
    this.#startCall = startCall;
    this.#refuseCall = refuseCall;
  }

  /** Whether any request waits for the admission's answer. */
  get hasWaiting(): boolean {
    return this.#waiting.size > 0;
  }

  /**
   * Makes the requests match the calls that are ready: asks for a slot for
   * each ready call that has no request, and withdraws the requests that no
   * ready call needs any more.
   *
   * @param ready For each context that has ready items: the number of calls
   *   that they form.
   */
  match(ready: readonly (readonly [context: Context, calls: number])[]): void {
    if (this.#waiting.size > 0) this.#withdrawSurplus(ready);

    // The requests of one `match` call share one captured async context,
    // which is captured only if one of them has to wait.
    const shared: { runInContext: RunInContext | undefined } = {
      runInContext: undefined,
    };
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Requests each missing slot; the path of every call.
    for (const [context, calls] of ready) {
      const requested =
        this.#waiting.size === 0 ? 0 : (this.#waiting.get(context)?.size ?? 0);
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Requests each missing slot; the path of every call.
      for (let count = requested; count < calls; count += 1) {
        this.#request(context, shared);
      }
    }
  }

  #withdrawSurplus(
    ready: readonly (readonly [context: Context, calls: number])[],
  ): void {
    const callsByContext = new Map(ready);
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Withdraws each surplus request for its side effect.
    this.#waiting.forEach((requests, context) => {
      const surplus = requests.size - (callsByContext.get(context) ?? 0);
      if (surplus <= 0) return;
      // The newest requests go, so the oldest keep their place in the
      // admission's queue.
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Withdraws each surplus request for its side effect.
      [...requests].slice(-surplus).forEach((request) => {
        this.#answer(request);
        request.controller.abort(WITHDRAWN);
      });
    });
  }

  /** Asks the admission for the slot of one call of `context`. */
  #request(
    context: Context,
    shared: { runInContext: RunInContext | undefined },
  ): void {
    const request: SlotRequest<Context> = {
      context,
      controller: new AbortController(),
      answered: false,
      runInContext: undefined,
    };
    // oxlint-disable-next-line typescript/promise-function-async -- Passes the call's promise through to the admission.
    const start = () => {
      // An admission must call `start` at most once, and never after it
      // refused the request or the request was withdrawn.
      if (request.answered) return undefined;
      const { runInContext } = request;
      this.#answer(request);
      return runInContext === undefined
        ? this.#startCall(context)
        : runInContext(this.#startCall, context);
    };

    const admitted = this.#admit(request, start);
    if (admitted === true) return;
    if (admitted === false) {
      this.#refuse(request, undefined);
      return;
    }

    if (!request.answered) {
      // The request waits. Captured after `admit` returned, which is still
      // the async context of this `match` call.
      shared.runInContext ??= AsyncLocalStorage.snapshot();
      request.runInContext = shared.runInContext;
      const requests = this.#waiting.get(context) ?? new Set();
      this.#waiting.set(context, requests);
      requests.add(request);
    }
    // oxlint-disable-next-line no-void -- Handles the admission's answer; nothing awaits it.
    void admitted.then(
      (wasAdmitted) => {
        if (!wasAdmitted) this.#refuse(request, undefined);
      },
      (error: unknown) => {
        this.#refuse(request, error);
      },
    );
  }

  /** Calls the admission. An admission that throws refuses the request. */
  // oxlint-disable-next-line typescript/promise-function-async -- Passes the admission's answer through, which can be synchronous.
  #admit(
    request: SlotRequest<Context>,
    start: () => Promise<void> | undefined,
  ): boolean | Promise<boolean> {
    try {
      return this.#admission.admit(
        request.context,
        request.controller.signal,
        start,
      );
    } catch (error) {
      this.#refuse(request, error);
      return true;
    }
  }

  /** Marks a request as answered, and stops waiting for it. */
  #answer(request: SlotRequest<Context>): void {
    request.answered = true;
    if (request.runInContext === undefined) return;
    request.runInContext = undefined;
    const requests = this.#waiting.get(request.context);
    if (requests === undefined) return;
    requests.delete(request);
    if (requests.size === 0) this.#waiting.delete(request.context);
  }

  /** Refuses one call for the request's context, unless the request has an answer already. */
  #refuse(request: SlotRequest<Context>, cause: unknown): void {
    // A request that was withdrawn was answered by the withdrawal.
    if (request.answered) return;
    this.#answer(request);
    this.#refuseCall(request.context, cause);
  }
}
