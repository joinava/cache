export const GENERATOR_HINT =
  "For async work, use a generator callback with `yield* waitFor(...)`.";
export const TRAVERSAL_HINT =
  "For async work, use a generator callback with `yield* waitFor(...)` in timeSlicedMap or timeSlicedForEach first.";

/**
 * Returns `value` unchanged, or throws a `TypeError` if it is a thenable.
 *
 * TypeScript cannot reject a promise result without also rejecting generic
 * results, so the synchronous callback rule is checked here at runtime.
 */
export function assertNotThenable<Value>(
  value: Value,
  helper: string,
  hint: string,
): Value {
  if (
    ((typeof value === "object" && value !== null) ||
      typeof value === "function") &&
    "then" in value &&
    typeof value.then === "function"
  ) {
    throw new TypeError(
      `${helper} received a promise or other thenable from a synchronous callback. ${hint}`,
    );
  }
  return value;
}
