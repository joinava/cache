import type { Item } from "./item.js";

/** How a dispatcher accepts the work of one `submit` or `submitMany` call. */
export type SubmitOptions = {
  /**
   * Cancels the work that still waits when the signal aborts: its result
   * rejects with the signal's reason. Work whose call has started always
   * completes. If the signal has aborted already, the work is cancelled at
   * once, and never waits.
   *
   * It is for work that one caller owns. Do not pass it for work that a
   * `Sharing` starts: a `Sharing` cancels work only when every request for
   * it was cancelled.
   */
  signal?: AbortSignal | undefined;
  /**
   * Makes the work ready at once, without the wait that accumulates a
   * batch. It has the effect of `item.expedite()` on each item, but the
   * work never accumulates, so the waiting set arms no schedule for it.
   */
  expedite?: boolean | undefined;
};

/**
 * Cancels each of `items` that still waits when `signal` aborts. It stops
 * listening to the signal once every item has settled.
 *
 * @param items Items that a dispatcher has accepted. Some of them can have
 *   started, or settled, already.
 */
export function cancelWaitingOnAbort<Input, Result>(
  items: readonly Item<Input, Result>[],
  signal: AbortSignal,
): void {
  const cancelAll = () => {
    // `cancel` does nothing for an item that does not wait.
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Cancels each item for its side effect.
    items.forEach((item) => {
      item.cancel(signal.reason);
    });
  };
  // The signal can abort while the dispatcher accepts the items, because a
  // call can start then, and it runs the caller's code.
  if (signal.aborted) {
    cancelAll();
    return;
  }

  // A listener on an item that has settled never runs, so only the items
  // that have not settled are counted.
  const unsettled = items.filter((item) => item.state !== "settled");
  if (unsettled.length === 0) return;
  const state = { unsettledCount: unsettled.length };
  const onSettled = () => {
    state.unsettledCount -= 1;
    if (state.unsettledCount === 0) {
      signal.removeEventListener("abort", cancelAll);
    }
  };
  signal.addEventListener("abort", cancelAll, { once: true });
  // oxlint-disable-next-line zingage/no-restricted-syntax -- Listens to each item for its side effect.
  unsettled.forEach((item) => {
    item.onSettled(onSettled);
  });
}
