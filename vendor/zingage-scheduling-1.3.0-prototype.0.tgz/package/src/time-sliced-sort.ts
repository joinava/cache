import assert from "node:assert/strict";
import { TimeSliceBudget, timeSlicedForEach } from "./time-slicing.js";

/**
 * Returns a new, stably sorted array using a synchronous comparator.
 *
 * A negative result puts the left value first; a positive result puts the right
 * value first. Zero and NaN preserve input order. The comparator receives every
 * input value, including undefined. The input is not reordered.
 *
 * Measures copying, comparisons, and merge writes. Checks the budget after each
 * merge write, including writes that need no comparison. One comparator call
 * cannot be interrupted. A nested helper cannot interrupt its containing
 * measured segment. Uses O(n log n) work and O(n) additional memory.
 * The optional budget defaults to a new independent `TimeSliceBudget`.
 *
 * @example Sort a readonly input without reordering it.
 * const sorted = await timeSlicedSort([3, 1, 2] as const, (left, right) => left - right);
 *
 * @example Load values in a generator and share its budget with sorting.
 * const budget = new TimeSliceBudget();
 * const sortedPages = await timeSlicedMap([1, 2], function* (page) {
 *   const values = yield* waitFor(Promise.resolve([page + 1, page]));
 *   return yield* waitFor(timeSlicedSort(values, (left, right) => left - right, budget));
 * }, budget);
 */
export async function timeSlicedSort<Item>(
  items: Iterable<Item>,
  compare: (left: Item, right: Item) => number,
  budget = new TimeSliceBudget(),
): Promise<Item[]> {
  // Boxing distinguishes an absent buffer entry from a valid undefined input value.
  type Entry = { value: Item };
  const buffers: { source: Entry[]; target: Entry[]; width: number } = {
    source: [],
    target: [],
    width: 1,
  };
  /* oxlint-disable zingage/no-restricted-syntax -- Stable merging uses local buffers and sequential index updates to avoid quadratic copying and per-item promises. */
  await timeSlicedForEach(
    items,
    (value) => {
      buffers.source.push({ value });
    },
    budget,
  );
  const length = buffers.source.length;
  while (buffers.width < length) {
    const run = { start: 0 };
    while (run.start < length) {
      const middle = Math.min(run.start + buffers.width, length);
      const end = Math.min(run.start + 2 * buffers.width, length);
      const position = { left: run.start, right: middle, output: run.start };
      while (position.output < end) {
        budget.measure(() => {
          const left =
            position.left < middle ? buffers.source[position.left] : undefined;
          const right =
            position.right < end ? buffers.source[position.right] : undefined;
          assert.ok(left !== undefined || position.left === middle);
          assert.ok(right !== undefined || position.right === end);
          if (
            left !== undefined &&
            (right === undefined || !(compare(left.value, right.value) > 0))
          ) {
            buffers.target[position.output] = left;
            position.left += 1;
          } else {
            assert.ok(right);
            buffers.target[position.output] = right;
            position.right += 1;
          }
          position.output += 1;
        });
        const pending = budget.yieldIfNeeded();
        if (pending !== undefined) await pending;
      }
      run.start = end;
    }
    const previous = buffers.source;
    buffers.source = buffers.target;
    buffers.target = previous;
    buffers.width *= 2;
  }
  const result: Item[] = [];
  await timeSlicedForEach(
    buffers.source,
    (entry) => {
      result.push(entry.value);
    },
    budget,
  );
  /* oxlint-enable zingage/no-restricted-syntax */
  return result;
}
