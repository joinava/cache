/**
 * Decides when a call may start. It can let the call start at once, make it
 * wait, or refuse it. It holds no work: it holds only requests for a slot.
 * The dispatcher picks the items of a call when the slot is granted, so work
 * that waits for a slot stays in the waiting set.
 */
export type Admission<Context> = {
  /**
   * Calls `start` once, when a call for `context` may start. The slot is
   * held until the promise that `start` returns settles. `start` returns
   * `undefined` when nothing is left to run. Then no slot is used.
   *
   * @param signal Withdraws the request while it waits. A withdrawn request
   *   never calls `start`, and resolves `false`.
   * @returns `true` once `start` was called. `false` if the request was
   *   refused or withdrawn, and `start` was never called.
   */
  admit(
    context: Context,
    signal: AbortSignal,
    start: () => PromiseLike<unknown> | undefined,
  ): boolean | Promise<boolean>;
};

/** The reason of an item that was cancelled because its call was refused admission. */
export class AdmissionRefusedError extends Error {
  override readonly name: string = "AdmissionRefusedError";
}

type Start = () => PromiseLike<unknown> | undefined;
type Waiter = { readonly start: Start; readonly started: () => void };

/** Throws the errors that starts threw, if any. */
function throwStartErrors(errors: readonly unknown[]): void {
  if (errors.length === 1) throw errors[0];
  if (errors.length > 1) {
    throw new AggregateError(errors, "More than one start threw");
  }
}

/**
 * An {@link Admission} with a fixed number of slots. A request that finds no
 * free slot waits, and gets a slot in first-in, first-out order. It never
 * refuses a request. It ignores the context, so one limit covers every
 * context.
 *
 * `start` should not throw. If it does, it uses no slot, and the requests
 * that wait still get their slots.
 *
 * @param maxConcurrent The number of slots. It must be a positive integer.
 */
export function concurrencyLimit(maxConcurrent: number): Admission<unknown> {
  if (!Number.isInteger(maxConcurrent) || maxConcurrent < 1) {
    throw new TypeError("maxConcurrent must be a positive integer");
  }

  const state = { runningCount: 0, grantingSlots: false };
  // A Set keeps insertion order, and removes any member in constant time.
  const waiters = new Set<Waiter>();

  /** Frees one slot when its work settles, and gives it to the waiters. */
  const free = () => {
    state.runningCount -= 1;
    throwStartErrors(grantSlots());
  };

  /** Calls `start` in a free slot. Returns the error that it threw, if any. */
  const run = (start: Start): unknown[] => {
    state.runningCount += 1;
    const started = (() => {
      try {
        return { work: start(), errors: [] };
      } catch (error) {
        return { work: undefined, errors: [error] };
      }
    })();
    if (started.work === undefined) {
      state.runningCount -= 1;
      return started.errors;
    }
    // oxlint-disable-next-line no-void -- Frees the slot on settle; the caller owns the promise.
    void started.work.then(free, free);
    return [];
  };

  /** Gives free slots to the waiters, in order. Returns the errors that starts threw. */
  const grantSlots = (): unknown[] => {
    // A start can free its slot at once. The loop that already runs gives
    // that slot away, so a long row of such starts uses no recursion.
    if (state.grantingSlots) return [];
    state.grantingSlots = true;
    const errors: unknown[] = [];
    try {
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Loops until no slot is free or nothing waits; each start can change both.
      while (state.runningCount < maxConcurrent) {
        const [waiter] = waiters;
        if (waiter === undefined) break;
        waiters.delete(waiter);
        // oxlint-disable-next-line zingage/no-restricted-syntax -- Collects the errors of the starts, in order.
        errors.push(...run(waiter.start));
        waiter.started();
      }
    } finally {
      state.grantingSlots = false;
    }
    return errors;
  };

  return {
    // oxlint-disable-next-line typescript/promise-function-async -- Answers synchronously when it can, so a free slot costs no promise.
    admit(_context, signal, start) {
      if (signal.aborted) return false;
      if (state.runningCount < maxConcurrent && waiters.size === 0) {
        throwStartErrors([...run(start), ...grantSlots()]);
        return true;
      }

      const { promise, resolve } = Promise.withResolvers<boolean>();
      const onAbort = () => {
        waiters.delete(waiter);
        resolve(false);
      };
      const waiter: Waiter = {
        start,
        started: () => {
          signal.removeEventListener("abort", onAbort);
          resolve(true);
        },
      };
      waiters.add(waiter);
      signal.addEventListener("abort", onAbort, { once: true });
      return promise;
    },
  };
}
