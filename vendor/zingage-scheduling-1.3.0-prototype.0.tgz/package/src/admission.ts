/**
 * Decides when a call may start. It can let the call start at once, make it
 * wait, or refuse it. It holds no work: it holds only requests for a slot.
 * The dispatcher picks the items of a call when the slot is granted, so work
 * that waits for a slot stays in the waiting set.
 */
export type Admission<Context> = {
  /**
   * Calls `start` once, when a call for `context` may start. The slot is
   * held until the promise that `start` returns settles. `start` returns
   * `undefined` when nothing is left to run. Then no slot is used.
   *
   * @param signal Withdraws the request while it waits. A withdrawn request
   *   never calls `start`, and resolves `false`.
   * @returns `true` once `start` was called. `false` if the request was
   *   refused or withdrawn, and `start` was never called.
   */
  admit(
    context: Context,
    signal: AbortSignal,
    start: () => PromiseLike<unknown> | undefined,
  ): boolean | Promise<boolean>;
};

/** The reason of an item that was cancelled because its call was refused admission. */
export class AdmissionRefusedError extends Error {
  override readonly name: string = "AdmissionRefusedError";
}
