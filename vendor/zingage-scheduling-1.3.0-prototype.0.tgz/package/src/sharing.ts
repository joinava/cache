import type { Item } from "./item.js";
import { SchedulingContractError } from "./scheduling-contract-error.js";
import {
  cancelledOutcome,
  type SharedOutcome,
  type SharedRequest,
} from "./shared-outcome.js";
import {
  addRequestSignal,
  cancelIfUnused,
  hold,
  makeEntry,
  makeUncancellable,
  release,
  type Entry,
} from "./shared-entry.js";

/**
 * The keys that one running `start` call starts items for. The frames of
 * nested `start` calls form a list, innermost first.
 */
type StartFrame<Key> = {
  /** Says whether the call starts an item for `key`. */
  readonly starts: (key: Key) => boolean;
  readonly outer: StartFrame<Key> | undefined;
};

/** Whether two keys match as `Map` keys do. */
function sameKey(a: unknown, b: unknown): boolean {
  return a === b || (Number.isNaN(a) && Number.isNaN(b));
}

/** Marks a request of `requestMany` whose signal had already aborted. */
const CANCELLED = -1;

/**
 * What one `requestMany` call does with its requests, decided before the
 * call starts anything.
 *
 * Requests with the same key are one group. A request with no key is a
 * group of its own. A group's first request is its leader. This is the path
 * of every request of a bulk call, so the plan keeps its facts in arrays by
 * request index, and has no object for a group.
 */
type Plan<Input, Result, Key> = {
  /** For each request: its key. Undefined also for a cancelled request. */
  readonly keys: readonly (Key | undefined)[];
  /** For each request: the index of its group's leader, or `CANCELLED`. */
  readonly leaders: readonly number[];
  /**
   * At each leader's index: the entry that the group joins, or the reason
   * why it starts an item.
   */
  readonly decisions: readonly (Entry<Input, Result> | string | undefined)[];
  /** The leaders of the groups that start an item, in request order. */
  readonly startLeaders: readonly number[];
  /** The entries that the call joins. */
  readonly joinedEntries: readonly Entry<Input, Result>[];
  /** Says whether the call starts an item for `key`. */
  readonly starts: (key: Key) => boolean;
};

/**
 * Lets requests for the same work share one {@link Item}. It sits in front
 * of a dispatcher, and adds only sharing:
 *
 * - `keyOf` says which requests are for the same work. This class owns that
 *   key and its index. The dispatcher never sees it.
 * - `canJoin` says whether a request may join an item that already exists.
 *   It reads the item's state and times, so one function covers work that
 *   waits, work that runs, and a time window.
 * - It counts the requests on each item, and cancels an item that still
 *   waits when every request on it was cancelled.
 *
 * It keeps an item only until the item settles. For each key it keeps the
 * newest item: an item that a request did not join is replaced by the item
 * that the request starts, and keeps running.
 */
export class Sharing<Request, Input, Result, Key = string> {
  readonly #keyOf: (request: Request) => Key | undefined;
  readonly #canJoin: (
    item: Item<Input, Result>,
    request: Request,
    now: number,
  ) => true | string;
  readonly #start: (requests: readonly Request[]) => Item<Input, Result>[];
  readonly #now: () => number;

  /** For each key, the newest item that has not settled. */
  readonly #entryByKey = new Map<Key, Entry<Input, Result>>();
  /**
   * The entry of each item that a request joined. An item that no request
   * joined is not here, because its count is 0 and this map is slow to write.
   */
  readonly #joinedEntryByItem = new WeakMap<
    Item<Input, Result>,
    Entry<Input, Result>
  >();
  /**
   * The keys that the running `start` calls start items for. Defined only
   * while `start` runs. Those items are indexed only after `start` returns.
   * So when `start` runs work synchronously, and that work requests its own
   * key, the nested request could not join the item and would start it
   * again, without end. The nested request throws instead.
   */
  #starting: StartFrame<Key> | undefined;

  constructor(options: {
    /**
     * Gives the key of a request, once for each request. Requests with the
     * same key are for the same work. Keys match as `Map` keys do. Return
     * `undefined` for a request that must never share work.
     */
    keyOf: (request: Request) => Key | undefined;
    /**
     * Says whether `request` may join `item`, which has the same key and has
     * not settled. Return `true`, or the reason why not, for diagnostics.
     * `now` uses the same clock as the item's times.
     */
    canJoin: (
      item: Item<Input, Result>,
      request: Request,
      now: number,
    ) => true | string;
    /**
     * Starts one item for each request, in order, normally with a
     * dispatcher's `submitMany`. One call gets every new item of one
     * `requestMany` call, so the items start together or not at all.
     */
    start: (requests: readonly Request[]) => Item<Input, Result>[];
    /**
     * The clock for `canJoin`'s `now`. Use the dispatcher's clock. Defaults
     * to `performance.now()`.
     */
    now?: (() => number) | undefined;
  }) {
    this.#keyOf = options.keyOf;
    this.#canJoin = options.canJoin;
    this.#start = options.start;
    this.#now = options.now ?? (() => performance.now());
  }

  /**
   * `requestMany` for one request, with the same result. It is a separate
   * path because one request needs no grouping, and this is the path of a
   * caller that requests one thing at a time.
   */
  request(
    request: Request,
    signal?: AbortSignal,
  ): SharedOutcome<Input, Result> {
    const key = signal?.aborted ? undefined : this.#keyOf(request);
    // Read again after the key: `keyOf` is user code and can abort the signal.
    if (signal?.aborted) return cancelledOutcome(signal.reason);
    if (key === undefined)
      return this.#startOne(undefined, request, signal, "noKey");
    if (this.#starting !== undefined) this.#assertNotStarting(key);

    const decision = this.#decide(key, request, undefined);
    if (typeof decision === "string") {
      return this.#startOne(key, request, signal, decision);
    }
    this.#addRequest(decision, signal, true);
    return {
      result: decision.item.result,
      item: decision.item,
      joined: true,
      startReason: undefined,
    };
  }

  /** Starts an item for one request, and records the request on it. */
  #startOne(
    key: Key | undefined,
    request: Request,
    signal: AbortSignal | undefined,
    startReason: string,
  ): SharedOutcome<Input, Result> {
    const items =
      key === undefined
        ? this.#start([request])
        : this.#startInFrame([request], (other) => sameKey(other, key));
    const [item] = items;
    if (item === undefined || items.length !== 1) {
      throw new SchedulingContractError(
        "start must return one item for each request",
      );
    }

    const entry = this.#index(item, key, signal !== undefined);
    this.#addRequest(entry, signal, false);
    // The request can have been cancelled while `start` ran.
    cancelIfUnused(entry);
    return { result: item.result, item, joined: false, startReason };
  }

  /**
   * Each request joins an item for its key, or starts one. Returns one
   * outcome for each request, in order.
   *
   * - Requests of this call with the same key always share one item,
   *   whatever `canJoin` says. If the call starts that item, the first of
   *   them started it, and the others joined it.
   * - Such a group joins an item that already exists only if `canJoin`
   *   accepts every request of the group. Otherwise the group starts one new
   *   item, which replaces the old one for later requests.
   * - Every key and every decision is computed, at one `now`, before
   *   anything starts. So when `keyOf`, `canJoin` or `start` throws, the
   *   call throws and changes nothing.
   * - A request whose signal already aborted joins and starts nothing. The
   *   other requests are not affected.
   *
   * @throws {SchedulingContractError} If `start` synchronously requests a
   *   key that this call is starting, or returns the wrong number of items.
   */
  requestMany(
    requests: readonly SharedRequest<Request>[],
  ): SharedOutcome<Input, Result>[] {
    const plan = this.#plan(requests);
    // Hold each entry that the call joins until its requests are recorded,
    // so that a cancellation during `start` cannot cancel it first.
    hold(plan.joinedEntries);
    try {
      const started = this.#startMany(requests, plan);
      const outcomes = requests.map(({ signal }, index) =>
        this.#record(plan, started, index, signal),
      );
      // A new item whose requests were all cancelled while `start` ran has
      // nothing that keeps it alive.
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Checks each new entry for its side effect.
      plan.startLeaders.forEach((leader) => {
        // oxlint-disable-next-line typescript/no-non-null-assertion -- #startMany returned an entry for each of these leaders.
        cancelIfUnused(started[leader]!);
      });
      return outcomes;
    } finally {
      release(plan.joinedEntries);
    }
  }

  /** Groups the requests of one `requestMany` call, and decides for each group. */
  #plan(requests: readonly SharedRequest<Request>[]): Plan<Input, Result, Key> {
    const count = requests.length;
    // A cancelled request needs no key. Signals are read again after the
    // keys, because `keyOf` is user code and can abort a signal.
    const keys = requests.map(({ request, signal }) =>
      signal?.aborted ? undefined : this.#keyOf(request),
    );
    const leaders = Array<number>(count);
    const decisions = Array<Entry<Input, Result> | string | undefined>(count);
    const leaderByKey = new Map<Key, number>();
    const now = this.#now();

    // oxlint-disable-next-line zingage/no-restricted-syntax -- Groups and decides each request; the path of every request of a bulk call.
    for (let index = 0; index < count; index += 1) {
      // oxlint-disable-next-line typescript/no-non-null-assertion -- index < count.
      const { request, signal } = requests[index]!;
      const key = keys[index];
      const leader = key === undefined ? undefined : leaderByKey.get(key);
      if (signal?.aborted) {
        // Decided once, here, so that a later abort cannot change which
        // requests this call treats as cancelled.
        leaders[index] = CANCELLED;
      } else if (leader !== undefined) {
        leaders[index] = leader;
        const decision = decisions[leader];
        // The group joins only if `canJoin` accepts every request of it.
        if (decision !== undefined && typeof decision !== "string") {
          const answer = this.#canJoin(decision.item, request, now);
          if (answer !== true) decisions[leader] = answer;
        }
      } else if (key === undefined) {
        leaders[index] = index;
        decisions[index] = "noKey";
      } else {
        if (this.#starting !== undefined) this.#assertNotStarting(key);
        leaders[index] = index;
        leaderByKey.set(key, index);
        decisions[index] = this.#decide(key, request, now);
      }
    }

    // After the loop, because a later request of a group can change the
    // group's decision.
    const startLeaders: number[] = [];
    const joinedEntries: Entry<Input, Result>[] = [];
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Sorts each group by its decision; the path of every request of a bulk call.
    for (let index = 0; index < count; index += 1) {
      const decision = leaders[index] === index ? decisions[index] : undefined;
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Collects the leaders, in order.
      if (typeof decision === "string") startLeaders.push(index);
      // oxlint-disable-next-line zingage/no-restricted-syntax -- Collects the joined entries.
      else if (decision !== undefined) joinedEntries.push(decision);
    }

    return {
      keys,
      leaders,
      decisions,
      startLeaders,
      joinedEntries,
      starts: (key) =>
        typeof decisions[leaderByKey.get(key) ?? CANCELLED] === "string",
    };
  }

  /** Records the request at `index` on its group's entry, and gives its outcome. */
  #record(
    plan: Plan<Input, Result, Key>,
    started: readonly (Entry<Input, Result> | undefined)[],
    index: number,
    signal: AbortSignal | undefined,
  ): SharedOutcome<Input, Result> {
    // oxlint-disable-next-line typescript/no-non-null-assertion -- The plan has a leader for every request.
    const leader = plan.leaders[index]!;
    if (leader === CANCELLED) return cancelledOutcome(signal?.reason);

    const decision = plan.decisions[leader];
    const startReason = typeof decision === "string" ? decision : undefined;
    // oxlint-disable-next-line typescript/no-non-null-assertion -- A leader has a decision, and #startMany returned an entry for each leader that starts an item.
    const entry = (typeof decision === "string" ? started[leader] : decision)!;
    const joined = startReason === undefined || index !== leader;
    this.#addRequest(entry, signal, joined);
    return {
      result: entry.item.result,
      item: entry.item,
      joined,
      startReason: joined ? undefined : startReason,
    };
  }

  /**
   * The number of requests that joined `item` without starting it, so far.
   * It counts a request that was cancelled later. 0 for an item that this
   * object does not know.
   */
  joinedCount(item: Item<Input, Result>): number {
    return this.#joinedEntryByItem.get(item)?.joinedCount ?? 0;
  }

  /**
   * The entry that a first request for `key` joins, or the reason why it
   * starts an item.
   *
   * @param now The clock time for `canJoin`. When undefined, the clock is
   *   read here, and only if an item exists.
   */
  #decide(
    key: Key,
    request: Request,
    now: number | undefined,
  ): Entry<Input, Result> | string {
    const existing = this.#entryByKey.get(key);
    if (existing === undefined || existing.item.state === "settled") {
      return "nothingPending";
    }
    const answer = this.#canJoin(existing.item, request, now ?? this.#now());
    return answer === true ? existing : answer;
  }

  /** @throws {SchedulingContractError} If a running `start` call starts an item for `key`. */
  #assertNotStarting(key: Key): void {
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Walks the list of frames.
    for (let frame = this.#starting; frame; frame = frame.outer) {
      if (frame.starts(key)) {
        throw new SchedulingContractError(
          "start requested a key that it is starting an item for",
        );
      }
    }
  }

  /** Calls `start`, and guards the keys that it starts items for meanwhile. */
  #startInFrame(
    requests: readonly Request[],
    starts: (key: Key) => boolean,
  ): Item<Input, Result>[] {
    const outer = this.#starting;
    this.#starting = { starts, outer };
    try {
      return this.#start(requests);
    } finally {
      this.#starting = outer;
    }
  }

  /**
   * Starts one item for each group of the plan that starts one, with one
   * `start` call, and indexes the items.
   *
   * @returns At the index of each leader that starts an item: the item's entry.
   */
  #startMany(
    requests: readonly SharedRequest<Request>[],
    plan: Plan<Input, Result, Key>,
  ): readonly (Entry<Input, Result> | undefined)[] {
    const leaders = plan.startLeaders;
    if (leaders.length === 0) return [];

    const items = this.#startInFrame(
      // oxlint-disable-next-line typescript/no-non-null-assertion -- A leader is the index of a request.
      leaders.map((leader) => requests[leader]!.request),
      plan.starts,
    );
    if (items.length !== leaders.length) {
      throw new SchedulingContractError(
        "start must return one item for each request",
      );
    }

    const entries = Array<Entry<Input, Result> | undefined>(requests.length);
    // oxlint-disable-next-line zingage/no-restricted-syntax -- Indexes each item for its side effect.
    leaders.forEach((leader, position) => {
      entries[leader] = this.#index(
        // oxlint-disable-next-line typescript/no-non-null-assertion -- The length check above guarantees one item for each leader.
        items[position]!,
        plan.keys[leader],
        // A later request of the group can still make the item uncancellable.
        requests[leader]?.signal !== undefined,
      );
    });
    return entries;
  }

  /**
   * Makes the entry of a new item, and indexes it under its key until the
   * item settles.
   *
   * @param cancellable Whether the request that starts the item has a signal.
   */
  #index(
    item: Item<Input, Result>,
    key: Key | undefined,
    cancellable: boolean,
  ): Entry<Input, Result> {
    const entry = makeEntry(item, cancellable);
    // `start` can return an item that has settled already, for example one
    // that was refused. Nothing can join such an item.
    if (item.state === "settled") return entry;

    if (key !== undefined) this.#entryByKey.set(key, entry);
    // An item with no key and no signal has nothing to clean up.
    if (key !== undefined || cancellable) {
      item.onSettled(() => {
        makeUncancellable(entry);
        // The index can hold a newer item for the key, which replaced this
        // one.
        if (key !== undefined && this.#entryByKey.get(key) === entry) {
          this.#entryByKey.delete(key);
        }
      });
    }
    return entry;
  }

  /** Records one request on an entry's item. */
  #addRequest(
    entry: Entry<Input, Result>,
    signal: AbortSignal | undefined,
    joined: boolean,
  ) {
    if (joined) {
      if (entry.joinedCount === 0) {
        this.#joinedEntryByItem.set(entry.item, entry);
      }
      entry.joinedCount += 1;
    }
    // `start` runs user code, so the signal can have aborted since the call
    // read it.
    addRequestSignal(entry, signal);
  }
}
