import type { Item } from "./item.js";

/**
 * One item that requests share, and the requests on it. The functions in
 * this file keep its counts. `Sharing` decides which requests go on which
 * entry.
 */
export type Entry<Input, Result> = {
  readonly item: Item<Input, Result>;
  /** The requests that joined the item without starting it. */
  joinedCount: number;
  /**
   * Undefined when the item cannot be cancelled: a request without a signal
   * is on it, or it has settled.
   */
  cancellation:
    | {
        /** The requests, and holds, that keep the item from being cancelled. */
        uncancelled: number;
        /** The signal reason of the last request to be cancelled. */
        lastReason: unknown;
        /** Removed when the item can no longer be cancelled. */
        readonly listeners: [signal: AbortSignal, listener: () => void][];
      }
    | undefined;
};

/**
 * Makes the entry of a new item.
 *
 * @param cancellable Whether the request that starts the item has a signal.
 *   An item that has settled already can never be cancelled.
 */
export function makeEntry<Input, Result>(
  item: Item<Input, Result>,
  cancellable: boolean,
): Entry<Input, Result> {
  return {
    item,
    joinedCount: 0,
    cancellation:
      cancellable && item.state !== "settled"
        ? { uncancelled: 0, lastReason: undefined, listeners: [] }
        : undefined,
  };
}

/** Cancels the item if it can be cancelled and no request keeps it alive. */
export function cancelIfUnused<Input, Result>(
  entry: Entry<Input, Result>,
): void {
  const { cancellation } = entry;
  if (cancellation === undefined || cancellation.uncancelled > 0) return;
  // Does nothing unless the item still waits: work that started completes.
  entry.item.cancel(cancellation.lastReason);
}

/** Stops the tracking of cancellations: the item can no longer be cancelled. */
export function makeUncancellable<Input, Result>(
  entry: Entry<Input, Result>,
): void {
  const { cancellation } = entry;
  if (cancellation === undefined) return;
  entry.cancellation = undefined;
  // oxlint-disable-next-line zingage/no-restricted-syntax -- Removes each listener for its side effect.
  cancellation.listeners.forEach(([signal, listener]) => {
    signal.removeEventListener("abort", listener);
  });
}

/**
 * Records one request's signal on an entry. The item is cancelled when the
 * signals of all its requests have aborted, if it still waits then.
 */
export function addRequestSignal<Input, Result>(
  entry: Entry<Input, Result>,
  signal: AbortSignal | undefined,
): void {
  const { cancellation } = entry;
  if (cancellation === undefined) return;
  // A request without a signal can never be cancelled, so neither can the item.
  if (signal === undefined) {
    makeUncancellable(entry);
    return;
  }
  // The signal can have aborted since the caller read it.
  if (signal.aborted) {
    cancellation.lastReason = signal.reason;
    return;
  }

  cancellation.uncancelled += 1;
  const listener = () => {
    cancellation.lastReason = signal.reason;
    cancellation.uncancelled -= 1;
    cancelIfUnused(entry);
  };
  signal.addEventListener("abort", listener, { once: true });
  // oxlint-disable-next-line zingage/no-restricted-syntax -- The entry owns its listener list, and removes every listener later.
  cancellation.listeners.push([signal, listener]);
}

/**
 * Keeps the entries' items from being cancelled until `release`. A caller
 * holds the entries that it will add requests to, while it runs user code
 * that can abort the signals of the requests that are on them now.
 */
export function hold<Input, Result>(
  entries: readonly Entry<Input, Result>[],
): void {
  // oxlint-disable-next-line zingage/no-restricted-syntax -- Holds each entry for its side effect.
  entries.forEach((entry) => {
    if (entry.cancellation) entry.cancellation.uncancelled += 1;
  });
}

/** Ends a `hold`, and cancels the items that nothing keeps alive any more. */
export function release<Input, Result>(
  entries: readonly Entry<Input, Result>[],
): void {
  // oxlint-disable-next-line zingage/no-restricted-syntax -- Releases each entry for its side effect.
  entries.forEach((entry) => {
    if (!entry.cancellation) return;
    entry.cancellation.uncancelled -= 1;
    cancelIfUnused(entry);
  });
}
