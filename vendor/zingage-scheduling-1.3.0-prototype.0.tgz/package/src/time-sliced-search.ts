import { TRAVERSAL_HINT, assertNotThenable } from "./synchronous-result.js";
import { TimeSliceBudget } from "./time-slicing.js";

async function findFirstMatch<Item>(
  helper: string,
  items: Iterable<Item>,
  predicate: (item: Item, index: number) => boolean,
  budget: TimeSliceBudget,
): Promise<{ item: Item } | undefined> {
  const position = { index: 0 };
  // oxlint-disable-next-line zingage/no-restricted-syntax -- Stop at the first match; native iteration closes the iterator without advancing it.
  for (const item of items) {
    const matched = budget.measure(() =>
      assertNotThenable(
        predicate(item, position.index),
        helper,
        TRAVERSAL_HINT,
      ),
    );
    position.index += 1;
    const pending = budget.yieldIfNeeded();
    if (pending !== undefined) await pending;
    if (matched) return { item };
  }
  return undefined;
}

/**
 * Returns whether any item matches a synchronous predicate, in input order.
 *
 * Stops at the first match. It does not advance the iterable past that item,
 * and it builds no intermediate array. Measures each predicate call, including
 * calls that throw. One predicate call cannot be interrupted. Throws a
 * `TypeError` if the predicate returns a promise or other thenable.
 * The optional budget defaults to a new independent `TimeSliceBudget`.
 *
 * @example Check for a negative number.
 * const hasNegative = await timeSlicedSome([3, -1, 2], (value) => value < 0);
 *
 * @example Share a budget with other work, and stop early on a lazy source.
 * const budget = new TimeSliceBudget();
 * const found = await timeSlicedSome(map.values(), (entry) => entry.active, budget);
 */
export async function timeSlicedSome<Item>(
  items: Iterable<Item>,
  predicate: (item: Item, index: number) => boolean,
  budget = new TimeSliceBudget(),
): Promise<boolean> {
  return (
    (await findFirstMatch("timeSlicedSome", items, predicate, budget)) !==
    undefined
  );
}

/**
 * Returns the first item that matches a type-guard predicate, narrowed.
 *
 * @example Find the first string.
 * const text = await timeSlicedFind(
 *   [1, "a", 2],
 *   (value): value is string => typeof value === "string",
 * );
 */
export function timeSlicedFind<Item, Found extends Item>(
  items: Iterable<Item>,
  predicate: (item: Item, index: number) => item is Found,
  budget?: TimeSliceBudget,
): Promise<Found | undefined>;
/**
 * Returns the first item that matches a synchronous predicate, or `undefined`.
 *
 * Stops at the first match. It does not advance the iterable past that item,
 * and it builds no intermediate array. Measures each predicate call, including
 * calls that throw. One predicate call cannot be interrupted. Throws a
 * `TypeError` if the predicate returns a promise or other thenable. As with
 * `Array.prototype.find`, a matching `undefined` item also returns `undefined`.
 * The optional budget defaults to a new independent `TimeSliceBudget`.
 *
 * @example Find the first even number.
 * const even = await timeSlicedFind([1, 4, 6], (value) => value % 2 === 0);
 *
 * @example Use the index and a shared budget.
 * const budget = new TimeSliceBudget();
 * const late = await timeSlicedFind(["a", "b"], (_, index) => index > 0, budget);
 */
export function timeSlicedFind<Item>(
  items: Iterable<Item>,
  predicate: (item: Item, index: number) => boolean,
  budget?: TimeSliceBudget,
): Promise<Item | undefined>;
export async function timeSlicedFind<Item>(
  items: Iterable<Item>,
  predicate: (item: Item, index: number) => boolean,
  budget = new TimeSliceBudget(),
): Promise<Item | undefined> {
  return (await findFirstMatch("timeSlicedFind", items, predicate, budget))
    ?.item;
}
