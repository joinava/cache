import { default as debug } from "debug";

/** The components in this package that write log lines. */
export type SchedulingComponentName = "batcher" | "collapsed-task-creator";

/**
 * The signature of a custom log function. `Batcher` and
 * `wrapWithTaskCollapsing` accept one, and call it when they log a message.
 *
 * A logger that accepts more component names, such as a logger shared with
 * other packages, is also a valid `Logger`.
 */
export type Logger = (
  component: SchedulingComponentName,
  level: "trace" | "debug" | "info" | "warn" | "error" | "fatal",
  message: string,
  data?: unknown,
) => void;

/** A logger that writes to the `debug` namespace `@zingage/scheduling:<name>`. */
function debugLogger(name: SchedulingComponentName): Logger {
  const write = debug(`@zingage/scheduling:${name}`);
  return (_, level, message, data) => {
    write(`(${level}) ${message} %O`, data);
  };
}

/** The default logger of each component. */
export const defaultLoggersByComponent = {
  batcher: debugLogger("batcher"),
  "collapsed-task-creator": debugLogger("collapsed-task-creator"),
} satisfies Record<SchedulingComponentName, Logger>;
