import type { Item } from "./item.js";

/** One request to share work or to start it. */
export type SharedRequest<Request> = {
  readonly request: Request;
  /**
   * Cancels the request. A request without a signal can never be cancelled,
   * so the item that it joins or starts can never be cancelled either.
   */
  readonly signal?: AbortSignal | undefined;
};

/** What `Sharing` returns for one request. */
export type SharedOutcome<Input, Result> = {
  /**
   * The shared result. It does not reject when only this request is
   * cancelled, because the item's other requests can still need it. A caller
   * races its own signal.
   */
  readonly result: Promise<Result>;
  /**
   * The item that the request joined or started. Undefined only for a
   * request that was already cancelled: it joins and starts nothing, and its
   * `result` rejects with the signal's reason.
   */
  readonly item: Item<Input, Result> | undefined;
  /** True when the request joined work that it did not start. */
  readonly joined: boolean;
  /**
   * Why the request started work instead of joining some: `"noKey"`,
   * `"nothingPending"`, or the reason that `canJoin` gave. Undefined for a
   * request that joined, and for one that was already cancelled.
   */
  readonly startReason: string | undefined;
};

/** The outcome of a request whose signal had already aborted. */
export function cancelledOutcome<Input, Result>(
  reason: unknown,
): SharedOutcome<Input, Result> {
  // oxlint-disable-next-line typescript/prefer-promise-reject-errors -- Rejects with the signal's abort reason, which can be any value.
  const result = Promise.reject<Result>(reason);
  // oxlint-disable-next-line no-void -- Marks the rejection as handled; the caller still gets the rejected promise.
  void result.catch(() => {});
  return { result, item: undefined, joined: false, startReason: undefined };
}
